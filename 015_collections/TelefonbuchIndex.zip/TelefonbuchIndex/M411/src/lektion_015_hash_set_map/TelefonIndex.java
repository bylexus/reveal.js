package lektion_015_hash_set_map;

import java.util.HashSet;
import java.util.Set;

public class TelefonIndex {

	public static void main(String[] args) {
		TelefonbuchEintrag[] eintraege = {
			new TelefonbuchEintrag("Anglin", "Allene", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Anglin", "Uriel", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Applbaum", "Alfreda", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Applbaum", "Carce", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Barrows", "Hephzibah", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Caba", "Chip", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Caba", "Randa", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Callanan", "Red", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Calnan", "Baillie", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Calnan", "Vickie", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Colombo", "Artair", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Colombo", "Lucais", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Colombo", "Pacorro", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Coogan", "Maryanne", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Garrett", "Maddy", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Garrett", "Viviana", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Hendon", "Fanya", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Hendon", "Rufe", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Keating", "Christyna", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Kimberley", "Cecily", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Kosslyn", "Bell", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Kosslyn", "Isador", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Law", "Horatio", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Law", "Jenn", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Leakey", "Hastie", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Leibundgut", "Bree", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Mccaffery", "Alisa", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Mcelwee", "Eberto", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Nadherny", "Hanan", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("O'connor", "Edee", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("O'connor", "Nobe", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Ostapchuk", "Korry", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Ostapchuk", "Trefor", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Parton", "Aubree", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Reheem", "Merrill", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Spicer", "Darcee", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Spicer", "Gram", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Sydor", "Frederigo", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Sydor", "Jacquelynn", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Sydor", "Joyous", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Sydor", "Martyn", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Wang", "Edd", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Wang", "Jewelle", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Wang", "Penny", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Waterman", "Arther", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Waterman", "Steffi", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Wollaston-joury", "Jaime", Double.toString(Math.random()*100000)),
			new TelefonbuchEintrag("Wollaston-joury", "Margaretha", Double.toString(Math.random()*100000))
		};
		
		// Index aufbauen:
		Telefonbuch buch = new Telefonbuch();
		for (TelefonbuchEintrag eintrag : eintraege) {
			buch.add(eintrag);
		}
		
		// Suchen eines Eintrages:
		TelefonbuchEintrag eintrag = buch.searchByName("Spicer", "Gram");
		System.out.println("Eintrag gefunden: " + eintrag.name+" " + eintrag.vorname+": "+eintrag.nr);
	}
}
