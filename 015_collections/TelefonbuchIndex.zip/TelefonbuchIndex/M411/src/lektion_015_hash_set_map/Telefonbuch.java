package lektion_015_hash_set_map;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Telefonbuch {
	private Map<String, List<TelefonbuchEintrag>> buch = new HashMap<>();
	
	public void add(TelefonbuchEintrag e) {
		// Einfüllen:
		// als Schlüssel den 1. Buchstaben des Nachnamens verwenden
		// als Wert haben wir eine Linked List mit allen Einträgen
		String key = e.name.substring(0,1);
		if (buch.containsKey(key) != true) {
			buch.put(key, new LinkedList<>());
		}
		// Eintrag in Liste einfügen: Jeder Key hat eine eigene Liste!
		buch.get(key).add(e);
	}
	
	public TelefonbuchEintrag searchByName(String name, String vorname) {
		String schluessel = name.substring(0,1);
		if (buch.containsKey(schluessel)) {
			List<TelefonbuchEintrag> liste = buch.get(schluessel);
			for (TelefonbuchEintrag e : liste) {
				if (e.name.equals(name) && e.vorname.equals(vorname)) {
					return e;
				}
			}
		}
		return null;
	}
}
