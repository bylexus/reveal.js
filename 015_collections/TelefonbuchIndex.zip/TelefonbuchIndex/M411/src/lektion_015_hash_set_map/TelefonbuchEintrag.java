package lektion_015_hash_set_map;

public class TelefonbuchEintrag {
	public String name;
	public String vorname;
	public String nr;
	
	public TelefonbuchEintrag(String name, String vorname, String nr) {
		this.name = name;
		this.vorname = vorname;
		this.nr = nr;
	}
}
