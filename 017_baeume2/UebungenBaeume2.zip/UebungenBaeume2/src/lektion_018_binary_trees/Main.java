package lektion_018_binary_trees;

public class Main {

	/**
	 * Naiver Ansatz, um einen Baum zu erstellen
	 */
	public static void main(String[] args) {
        String[] texte = {"Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrott", "Golf"};

		// Wurzelknoten erzeugen: 
		TreeNode wurzel = new TreeNode(texte[0], null,null);
		for (int i = 1; i< texte.length; i++) {
			wurzel.add(texte[i]);
		}

		wurzel = listToTree(texte,0,texte.length-1);
		
		TreeNode suchergebnis = search(wurzel, "Alpha");
		if (suchergebnis != null) System.out.println("Gefunden: "+suchergebnis.data);
		
		suchergebnis = search(wurzel, "Golf");
		if (suchergebnis != null) System.out.println("Gefunden: "+suchergebnis.data);
		
		suchergebnis = search(wurzel, "Noop");
		if (suchergebnis != null) System.out.println("Gefunden: "+suchergebnis.data); else System.err.println("Nix gefunden");

	}
	
	public static TreeNode listToTree(String[] liste, int startIndex, int endIndex) {
		int mittelIndex = (startIndex + endIndex) / 2;
		
		// Wurzel-Knoten erzeugen: das mittlere Element der Liste:
		TreeNode wurzel = new TreeNode(liste[mittelIndex],null,null);
		
		// Linke Seite: Teilliste von Start bis Mitte
		if (startIndex < mittelIndex) {
			TreeNode links = listToTree(liste, startIndex, mittelIndex - 1);
			if (links != null) {
				wurzel.left = links;
			}
		}
		
		// rechte Seite: Teilliste ab mitte bis Endindex:
		if (mittelIndex < endIndex) {
			TreeNode rechts = listToTree(liste, mittelIndex + 1, endIndex);
			if (rechts != null) {
				wurzel.right = rechts;
			}
		}
		
		return wurzel;
	}
	
	/**
	 * Suchfunktion, sucht einen Wert im binären Suchbaum
	 */
	public static TreeNode search(TreeNode wurzel, Comparable<String> suchwert) {
		// Suche starten auf sich selbst: Hat die Wurzel schon den gewünschten Wert?
		int vergleich = suchwert.compareTo(wurzel.data);
		if (vergleich == 0) {
			return wurzel;
		}
		// Wert ist kleiner als Wurzel: im linken Teilbaum suchen:
		if (vergleich < 0 && wurzel.left != null) {
			return search(wurzel.left, suchwert);
		}
		// Wert ist grösser als Wurzel: im rechten Teilbaum suchen:
		if (vergleich > 0 && wurzel.right != null) {
			return search(wurzel.right, suchwert);
		}
		// Nix gefunden:
		return null;
	}

}
