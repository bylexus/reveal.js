package lektion_018_binary_trees;

public class TreeNode {
	public TreeNode left;
	public TreeNode right;
	public String data;
	
	public TreeNode(String data, TreeNode left, TreeNode right) {
		this.data = data;
		this.left = left;
		this.right = right;
	}
	
	// Methode, um einen neuen Wert im (Teil-)Baum einzufügen:
	public TreeNode add(String data) {
		TreeNode node = new TreeNode(data, null, null);
		/// ..... hängt das neue Element in den Baum ein, und gibt die TreeNode zurück
		if (data.compareTo(this.data) < 0) {
			// links anhängen:
			if (this.left != null) {
				return this.left.add(data);
			} else {
				this.left = node;
			}
		} else {
			// rechts anhängen:
			if (this.right != null) {
				return this.right.add(data);
			} else {
				this.right = node;
			}
		}
		return node;
	}
	
	/**
	 * Aufgabe Einfacher Baum 1: inorder-Print-Methode
	 * 
	 * inorderPrint muss auf der Wurzel-Node aufgerufen werden:
	 * diese gibt dann die Elemente rekursiv aus.
	 */
	public void inorderPrint() {
		// Reihenfolge der Ausgabe:
		// 1. linker Teilbaum (rekursiv)
		// 2. sich selber
		// 3. rechter Teilbaum (rekursiv)
		if (this.left != null) {
			this.left.inorderPrint();
		}
		System.out.println(this.data);
		if (this.right != null) {
			this.right.inorderPrint();
		}
	}
	
	public void preorderPrint() {
		// Reihenfolge der Ausgabe:
		// 1. sich selber
		// 2. linker Teilbaum (rekursiv)
		// 3. rechter Teilbaum (rekursiv)
		System.out.println(this.data);
		if (this.left != null) {
			this.left.preorderPrint();
		}
		if (this.right != null) {
			this.right.preorderPrint();
		}
	}
}
