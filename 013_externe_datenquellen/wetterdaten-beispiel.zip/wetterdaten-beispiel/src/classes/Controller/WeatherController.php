<?php
namespace M151\Controller;

use M151\Http\Request;
use M151\Service\OpenWeatherDataParser;

class WeatherController extends Controller
{
    public function getWeather(Request $req)
    {
        $data = $this->fetchData();

        echo <<<EOT
        <!DOCTYPE html>
        <html>
        <head><title>Wetter</title></head>
        <style>
            html, body {
                font-family: Helvetica, sans-serif;
            }
        </style>
        <body>
        <h1>Wetter vom {$data->timestamp} in 8500 Frauenfeld</h1>
        <div style="display:flex">
        <img src="{$data->icon}" />
        <p>
     Es ist {$data->description}, bei {$data->temp}°C, {$data->humidity}% Luftfeuchtigkeit und {$data->pressure}hPa Luftdruck.
        </p>
        </div>
        </body>
        </html>
EOT;
    }

    protected function fetchData()
    {
        // $data = $this->readJSONData( '20915fef33b0fb948cf25547fa3d5da6', '8500', 'ch');
        // var_dump($this->readXMLData( '20915fef33b0fb948cf25547fa3d5da6', '8500', 'ch'));
        $data = $this->readXMLData('20915fef33b0fb948cf25547fa3d5da6', '8500', 'ch');
        $parser = new OpenWeatherDataParser();
        $res = $parser->parse($data);
        return $res;
    }

    protected function readJSONData($apiKey, $zip, $country)
    {
        // Daten als String von HTTP-API holen:

        $url = "http://api.openweathermap.org/data/2.5/weather?lang=de&units=metric&zip={$zip},{$country}&appid={$apiKey}";
        $response = file_get_contents($url);

        var_dump($response);
        die;

        // JSON-Antwort in Objekt konvertieren:
        $obj = json_decode($response);

        return $obj;
    }

    protected function readXMLData($apiKey, $zip, $country)
    {
        // Daten als String von HTTP-API holen:
        $url = "http://api.openweathermap.org/data/2.5/weather?mode=xml&lang=de&units=metric&zip={$zip},{$country}&appid={$apiKey}";
        $response = file_get_contents($url);
        // header('Content-Type: text/plain');

        // XML-Antwort parsen und in Objekt konvertieren:
        $obj = new \SimpleXMLElement($response);

        return $obj;
    }
}
