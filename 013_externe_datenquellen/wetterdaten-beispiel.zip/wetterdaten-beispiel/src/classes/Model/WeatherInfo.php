<?php

namespace M151\Model;


class WeatherInfo {
    public $timestamp;
    public $location;
    public $description;
    public $temp;
    public $pressure;
    public $humidity;
    public $icon;
}
