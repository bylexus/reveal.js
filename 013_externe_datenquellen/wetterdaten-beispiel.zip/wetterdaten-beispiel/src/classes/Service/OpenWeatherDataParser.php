<?php
namespace M151\Service;

use M151\Model\WeatherInfo;

class OpenWeatherDataParser
{
    public function parse($data)
    {
        if ($data instanceof \SimpleXMLElement) {
            return $this->parseXML($data);
        } else {
            return $this->parseJSON($data);
        }
    }

    protected function parseXML(\SimpleXMLElement $data)
    {
        // Zugriff auf SimpleXML-Daten siehe http://php.net/manual/en/simplexml.examples-basic.php
        $result = new WeatherInfo();
        $result->timestamp = strftime("%d.%m.%Y %H:%M", strtotime((string) $data->lastupdate['value']));
        $result->location = (string) $data->city['name'];
        $result->description = (string) $data->weather['value'];
        $result->temp = (string) $data->temperature['value'];
        $result->pressure = (string) $data->pressure['value'];
        $result->humidity = (string) $data->humidity['value'];
        $result->icon = "http://openweathermap.org/img/w/" . (string) $data->weather['icon'] . ".png";
        return $result;
    }
    protected function parseJSON($data)
    {

        $result = new WeatherInfo();
        $result->temp = $data->main->temp;
        $result->pressure = $data->main->pressure;
        $result->humidity = $data->main->humidity;
        $result->description = $data->weather[0]->description;
        $result->timestamp = strftime('%d.%m.%Y %H:%M', $data->dt);
        $result->icon = "http://openweathermap.org/img/w/" . (string) $data->weather[0]->icon . ".png";

        return $result;
    }
}
