<?php
use M151\Application;
use M151\Router;

# lade composer autoloader:
require_once __DIR__ . '/vendor/autoload.php';

// Wetter-Daten anzeigen
Router::get('/', M151\Controller\WeatherController::class, 'getWeather');
Router::get('/weather', M151\Controller\WeatherController::class, 'getWeather');

# Übergebe an Applikation:
$app = Application::getInstance();
$app->start();
