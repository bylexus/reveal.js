/**
 * 
 * @author chris
 * Hier eine ganze primitive Implementierungsvorschrift....die Definition des abstraken Datentyps Stack
 */
public interface Stack {
	/**
	 * Die Funktion pop() gibt uns das oberste Element zurück
	 * @return int
	 */
	int pop();
	
	/**
	 * Wir wollen etwas (ein int) im Stack ablegen (keine negativen Zahlen erlaubt)
	 * @param x
	 */
	void push(int x);
	
	/**
	 * Gibt einen Boolean zurück ob der Stack leer ist oder nicht
	 * @return
	 */
	boolean isEmpty();

}
