<?php
namespace M151;

class OverviewQueryBuilder extends QueryBuilder
{
    function __construct() 
    {
        parent::__construct();
    }

    public function getTable()
    {
        return "journal";
    }

    public function getColumns()
    {
        return "*";
    }

    public function query($params)
    {
        return parent::query($params);

    }
    
}

?>