<?php
namespace M151;
    class Template
    {
        private $vars = array();

        public function assign($key, $value)
        {
            $this->vars[$key] = $value;
        }

        public function render($template_name)
        {
            $path = $template_name . '.html';
            if(file_exists($path))
            {
                $contents = file_get_contents($path);
                foreach($this->vars as $key => $value)
                {
                    // echo ('/\[' . $key .'\]/');
                   
                    $contents = preg_replace('/\[' . $key .'\]/', $value, $contents);
                }
                $contents = preg_replace('/\[.*\]/', "", $contents);
                eval(' ?> ' . $contents . ' <?php ');
            }
            else
            {
                exit("<h1>Template Error: $path</h1>");
            }
        }
    }
?>

