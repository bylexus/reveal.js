<?php
namespace M151;
use M151\Template;
class Create extends Controller
{
    function __construct($name) 
    {
        parent::__construct();
        parent::$sql = new JournalQueryBuilder();
        $this->template->assign('action', '/Create/save');  
        $this->template->assign('header', 'Erstellen');  
        $this->template->assign('titelh4', 'Neues Lernjournal');  
        $this->template->assign('nav', file_get_contents('../src/views/navigation.html'));

        $taghtml = "";
        $kathtml = "";
        
        $tagsql = new TagQueryBuilder();
        $katsql = new KategorieQueryBuilder();
       
        
        $params = array("userid" => $_SESSION["user"]);
        $taglist = $tagsql->query($params);
        $katlist = $katsql->query($params);

        foreach($taglist as $key => $value)
        {
            $taghtml = $taghtml . "<option value='". $value['tagid'] ."'>". $value['tagname'] ."</option>";
        }
        foreach($katlist as $key => $value2)
        {
            $kathtml = $kathtml . "<option value='". $value2['id'] ."'>". $value2['kategorie'] ."</option>";
        }
        $this->template->assign('tags', $taghtml);  
        $this->template->assign('tagid', "");  
        $this->template->assign('katid', "");  
        $this->template->assign('kategorien', $kathtml);  
    }

    function update($id)
    {
        if(isset($id))
       {
            $params = array("id" => $id, "userid" => $_SESSION["user"]);
            $stm = parent::$sql->query($params);
            $error = true;
            foreach($stm as $key => $value)
            {

                $tag = "";
                $kat = "";
                
                $tagsqli = new TagQueryBuilder();
                $katsqli = new KategorieQueryBuilder();

                $paramstag = array("tagid" => $value['ftagid'], "userid" => $_SESSION["user"]);
                $paramskat = array("id" => $value['fkategorieid'], "userid" => $_SESSION["user"]);

                $taglist2 = $tagsqli->query($paramstag);
                $katlist2 = $katsqli->query($paramskat);
        
                foreach($taglist2 as $key => $value2)
                {
                    $tag = $value2['tagname'] ;
                    $tagid= $value2['tagid'] ;
                }
                foreach($katlist2 as $key => $value3)
                {
                    $kat = $value3['kategorie'];
                    $katid = $value3['id'];
                }
                $this->template->assign('selectedtag', $tag);  
                $this->template->assign('selectedkat', $kat);  

                $this->template->assign('tagid', $tagid);  
                $this->template->assign('katid', $katid);  

 
                $error = false;
                $nummer = $value['nummer'];
                $titel = $value['betreff'];
                $body = $value['body'];
                $this->template->assign('titelh4', 'Lernjournal bearbeiten');  
                $this->template->assign('action', '/Create/updatesave/'. $id);  
                $this->template->assign('header', 'Ändern');  
                $this->template->assign('nummer', $nummer);  
                $this->template->assign('titel', $titel);  
                $this->template->assign('body', $body); 
            }
            if($error)
            {
                echo("<script>alert('Falsche ID oder sie haben keine Berechtigungen diesen Eintrag zu Bearbeiten'); window.open('/Overview/showall','_self');</script>");
            }
       }        
    }

    function updatesave($id)
    {
        if(isset($_POST['nummer']) && isset($_POST['titel']) && isset($_POST['body']))
        {
            $nummer = $_POST['nummer'];
            $titel = $_POST['titel'];
            $body = $_POST['body'];
            $tag = $_POST['tag'];
            $kat = $_POST['kategorie'];
           

            $set = array("nummer" => $nummer, "betreff" => $titel, "body" => $body, "ftagid" => $tag, "fkategorieid" => $kat);
            $filter = array("id" => $id);
          
            
            $stm = parent::$sql->update($set, $filter);
            echo("<script>alert('Änderungen gespeichert')</script>");
            echo("<script>window.open('/Overview/showall','_self');</script>");
        }
        else
        {
            echo("<script>alert('Änderungen nicht gespeichert')</script>");
        }
    }
 
    function save()
    {
        if(isset($_POST['nummer']) && isset($_POST['titel']) && isset($_POST['body']))
        {
            
            $nummer = $_POST['nummer'];
            $tag = $_POST['tag'];
            $kat = $_POST['kategorie'];
            $titel = $_POST['titel'];
            $body = $_POST['body'];
            $userid = $_SESSION["user"];
            $date = date("d.m.Y");

            if($_POST['kategorie'] == "")
            {
                $kat = 0;
            }
            if($_POST['tag'] == "")
            {
                $tag = 0;
            }
            $columns = "id, nummer, betreff, body, userid, datum, deleted, ftagid, fkategorieid";
            $values = array(null, $nummer, $titel, $body, $userid, $date, 0, $tag, $kat); 
            $stm = parent::$sql->insert($columns, $values);
            echo("<script>alert('Journal gespeichert')</script>");
            echo("<script>window.open('/Overview/showall','_self');</script>");
        }
    }
    function render()
    {
        parent::renderpath('create');
    }
}

?>