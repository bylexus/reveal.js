<?php
namespace M151;
 class Connection
 {
    public $dbcon = null;
    private $dbhost; //Datenbankhost
    private $dbname; //Datenbankname
    private $dbuser; //Datenbankuser
    private $dbpass; //Datenbank Passwort
    private $options;
    public function __construct()
    {
        
        require('../src/dbconfig.php');
        
        try 
        {
            $this->dbcon = new \PDO("mysql:host=$this->dbhost;dbname=$this->dbname","$this->dbuser", "$this->dbpass");
        } 
        catch(PDOException $e)
        {
            die('Keine Verbindung zur Datenbank möglich: ' . $e->getMessage());
        }
    
    }
    
    public function getDBO()
    {
        return $this->dbcon;
    }
    
    public function sqlexec($type, $columns, $table, $params)
    {
        if($type == "select")
        {
            $statement = "Select $columns from $table where";
            $counter = 0;
            $values = array();
            foreach($params as $key => $value)
            {
                if($counter != 0)
                {
                    $statement = $statement . " AND";
                }
                $statement = $statement . " " . $key . " = ?";
                $values[$counter] = $value;
                $counter++;
            }
            $sql = $this->dbcon->prepare($statement);
            $sql->execute($values);
            $data = $sql->fetchAll();
            return $data;
        }
        else if($type == "insert")
        {
            $statement = "INSERT INTO $table ($columns) VALUES (";
            $counter = 0;
            $values = array();
            foreach($params as $key => $value)
            {
                if($counter != 0)
                {
                    $statement = $statement . " ,";
                }
                $statement = $statement . " ?";
                $values[$counter] = $value;
                $counter++;
            }
            $statement = $statement . ");";
            $sql = $this->dbcon->prepare($statement);
            $sql->execute($values);
        }
        else if($type == "update")
        {
            $statement = "UPDATE $table SET ";
            $counter = 0;
            $values = array();

            foreach($columns as $key => $value)
            {
                if($counter != 0)
                {
                    $statement = $statement . ", ";
                }
                
                $statement = $statement . " " . $key . " = ?";
                $values[$counter] = $value;
                $counter++;
            }

            $statement = $statement . " WHERE ";
            $counter2 = 0;
            foreach($params as $key => $value)
            {
                if($counter2 != 0)
                {
                    $statement = $statement . " AND ";
                }
                $statement = $statement . " " . $key . " = ?";
                $values[$counter] = $value;
                $counter++;
                $counter2++;
            }
            $statement = $statement . " ;";
            echo $statement;
            echo "<br>";
            var_dump($values);
            $sql = $this->dbcon->prepare($statement);
            $sql->execute($values);
        }
        else if($type == "delete")
        {
            $statement = "Delete from $table where";
            $counter = 0;
            $values = array();
            foreach($params as $key => $value)
            {
                if($counter != 0)
                {
                    $statement = $statement . " AND";
                }
                $statement = $statement . " " . $key . " = ?";
                $values[$counter] = $value;
                $counter++;
            }
            $sql = $this->dbcon->prepare($statement);
            $sql->execute($values);
           
        }
            
    }
 }
?>