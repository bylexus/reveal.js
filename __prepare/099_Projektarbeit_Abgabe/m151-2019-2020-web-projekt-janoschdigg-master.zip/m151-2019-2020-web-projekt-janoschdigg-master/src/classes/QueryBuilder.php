<?php
namespace M151;

abstract class QueryBuilder
{
    public $con = null;
    function __construct() 
    {
        $this->con = new Connection();
    }

    abstract public function getTable();
    abstract public function getColumns();
    
    public function query($params)
    {
        $columns =  $this->getColumns();
        $table = $this->getTable();
        $data = $this->con->sqlexec("select", $columns, $table, $params);
        return $data;
    }

    public function insert($columns, $values)
    {
        $table = $this->getTable();
        $this->con->sqlexec("insert", $columns, $table, $values);
    }
    public function update($set, $params)
    {
        $table = $this->getTable();
        $this->con->sqlexec("update", $set, $table, $params);
    }

    public function delete($filter)
    {
        $table = $this->getTable();
        $this->con->sqlexec("delete", null, $table, $filter);
    }
    
   
    
}

?>