<?php
namespace M151;
use M151\Template;

class Home extends Controller
{
    function __construct($name) 
    {
        parent::__construct();
        
        $this->template->assign('titel', "Herzlich Willkommen im Lernjournal");
        $this->template->assign('informationstext', "Hier kannst du deine Gedanken erfassen");
        if(!isset($_SESSION['user']) )
        {
            $this->template->assign('btn', "Login");
            $this->template->assign('link', "Login");
        }
        else{
            $this->template->assign('btn', "Lernjournal Übersicht");
            $this->template->assign('link', "overview/showall");
        }
        
        
    }

    function render()
    {
        parent::renderpath('home');
    }

    
    
}

?>