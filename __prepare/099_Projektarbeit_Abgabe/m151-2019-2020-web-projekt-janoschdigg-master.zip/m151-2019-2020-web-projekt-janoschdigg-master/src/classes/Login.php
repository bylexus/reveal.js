<?php
namespace M151;

use M151\Template;


class Login extends Controller
{
    public $loginsql;
    function __construct($param) 
    {
        
        $_SESSION["login"] = true;
        parent::__construct();
        parent::$sql = new LoginQueryBuilder();
    }

    function render()
    {
        $path = 'login';
        parent::renderpath($path);
    }

    function logout()
    {
        
		session_destroy();
    }

   
    

    

    function login_try()
    {
        function saltingPassword($password, $salt)
        {
            return hash('sha256', $password . $salt);
        }
        
        if(isset($_POST['username'])&& isset($_POST['password']) && $_POST['username'] != '' && $_POST['password'] != '')
        {
            $username = $_POST['username'];
            $password = $_POST['password'];
           
            $success = false;
           
            $params = array("login" => $username);
            $data = parent::$sql->query($params);
            
         
            foreach($data as $key => $value)
            {
                $salt = $value['id'];
                $hashedpw = saltingPassword($_POST['password'], $salt);

                if($value['passwort'] == $hashedpw)
                {
                    $success = true;
                    $_SESSION["user"] = $value['id'];
                    $_SESSION["login"] = $value['login'];
                    $_SESSION["username"] = $value['vorname'];
                    $_SESSION["admin"] = $value['admin'];
                    $_SESSION["pb"] = $value['Profile'];
                    $_SESSION["fullname"] = $value['vorname'] . " ". $value['name'];
                   
                   
                  
                    header('Location: /overview/showall');
                    $this->template->assign('alertclass', 'success');
                    $this->template->assign('alerttype', 'Hallo ');
                    $this->template->assign('alerttext', $value['vorname']);
                }
             }
            
            if(!$success)
            {
                $this->template->assign('alertclass', 'danger');
                $this->template->assign('alerttype', ' Login Fehlgeschlagen');
                $this->template->assign('alerttext', ' Versuchs mit anderen Angaben!');
            }

        }
    }
    
}

?>