<?php
namespace M151;
use M151\Template;

class Benutzer extends Controller
{
    public $path = "benutzer";
   
    function __construct() 
    {
        $path = "benutzer";
        parent::__construct();
        parent::$sql = new LoginQueryBuilder();
        $this->template->assign('nav', file_get_contents('../src/views/navigation.html'));
       
        $params = array("id" => $_SESSION['user']);                                                                                                   
        $stm = parent::$sql->query($params);
        foreach($stm as $key => $value)
        {
            $name = $value['login'];
            $password = "************";
            $this->template->assign('user', $name);
            $this->template->assign('password', $password);
            $this->template->assign('vorname', $value['vorname']);
            $this->template->assign('name', $value['name']);
            $this->template->assign('mail', $value['email']);

           
            $path = "/images/" . $value['Profile'];
            $img = "<img class='profilepicture' src='".$path."'/>";
            $this->template->assign('pb', $img);
        }
    }

    

    function saveprofile()
    {
        if(isset($_FILES["profile"]["tmp_name"]) && $_FILES["profile"]["tmp_name"] !="")
        {
            print_r($_FILES["profile"]);
            $params = array("id" => $_SESSION['user']);
            $stm = parent::$sql->query($params);
            $old = "";
            foreach($stm as $key => $value)
            {
                    $old = $value['Profile'];
            }
            echo $old;
            if($old != "default.jpg")
            {
                $dir2 = __DIR__ . "/../../webroot/images/" . $old;
                unlink($dir2);
            }
    
            $dir = __DIR__."/../../webroot/images/";
            $filename = basename($_FILES['profile']["name"]);
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            $new = uniqid().'.'.$ext;
            $_SESSION['pb'] = $new;
            // create_square_image($_FILES["profile"]["tmp_name"],null,200);
    
            if(!move_uploaded_file($_FILES["profile"]["tmp_name"], $dir.$new))
            {
                header("Location: /Benutzer");
            }
         
            
            $set = array("Profile" => $new);
            $filter = array("id" => $_SESSION['user']);
            $stm = parent::$sql->update($set, $filter);
            
        }
        header("Location: /Benutzer");
        
    }
    function savepassword()
    {   
        function saltingPassword($password, $salt)
        {
            return hash('sha256', $password . $salt);
        }

        $params = array("login" => $_SESSION['login']);
        $data = parent::$sql->query($params);
        foreach($data as $key => $value)
        {
                $salt = $value['id'];
                $hashedpw = saltingPassword($_POST['password'], $salt);
                $set = array("passwort" => $hashedpw);
                $filter = array("id" =>  $_SESSION['user']);
                $stm = parent::$sql->update($set, $filter);
        }
        echo("<script>alert('Passwort geändert'); window.open('/Benutzer','_self');</script>");
    }
    function render()
    {
        parent::renderpath($this->path);
    }
}

?>