<?php

namespace M151;
use M151\Template;

class Controller
{
    protected $template;
    protected static $sql;

    function __construct() 
    {
        session_start();
        $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        if (strpos($url,'Login') == false && strpos($url,'Home') == false) {
            if(!isset($_SESSION['user']) )
            {
                header("Location: /Login");
            }
        } 
        $this->template = new Template();
        
       
      
    }

   
    function renderpath($view)
    {

        $path = "/Users/janosch/GitHub/M151/src/views/" . $view;
        if(isset($_SESSION['fullname']) && isset($_SESSION['pb']))
        {
            $this->template->assign("fullname", $_SESSION['fullname']);
            $this->template->assign("benutzerbild", $_SESSION['pb']);
        }

        $this->template->assign("favicon", "<link rel='shortcut icon' type='image/png' href='/images/favicon.png'>");

        
        $this->template->render($path);
    }
    
    
}

?>
