<?php
namespace M151;

class LoginQueryBuilder extends QueryBuilder
{
    function __construct() 
    {
        parent::__construct();
    }

    public function getTable()
    {
        return "benutzer";
    }

    public function getColumns()
    {
        return "*";
    }

    public function query($params)
    {
        return parent::query($params);

    }
    public function update($set, $filter)
    {
        return parent::update($set, $filter);

    }
    
}

?>