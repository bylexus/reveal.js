<?php
namespace M151;
use M151\Template;

class Journal extends Controller
{   
    public $path = "show";
   
    function __construct() 
    {
        $path = "show";
        parent::__construct();
        parent::$sql = new JournalQueryBuilder();
        $this->template->assign('nav', file_get_contents('../src/views/navigation.html'));
    }

    function show($id)
    {
        $this->path = "show";
       if(isset($id))
       {
            $params = array("id" => $id, "userid" => $_SESSION["user"]);
            $stm = parent::$sql->query($params);
            $error = true;
            foreach($stm as $key => $value)
            {
                $error = false;

                $tag = "";
                $kat = "";
                
                $tagsqli = new TagQueryBuilder();
                $katsqli = new KategorieQueryBuilder();
        
                $paramstag = array("tagid" => $value['ftagid'], "userid" => $_SESSION["user"]);
                $paramskat = array("id" => $value['fkategorieid'], "userid" => $_SESSION["user"]);

                $taglist2 = $tagsqli->query($paramstag);
                $katlist2 = $katsqli->query($paramskat);
        
                foreach($taglist2 as $key => $value2)
                {
                    $tag = $value2['tagname'] ;
                }
                foreach($katlist2 as $key => $value3)
                {
                    $kat = $value3['kategorie'];
                }
                $this->template->assign('tag', $tag);
                $this->template->assign('kat', $kat);
                $this->template->assign('nummer', $value['nummer']);
                $this->template->assign('betreff', $value['betreff']);
                $this->template->assign('datum', $value['datum']);
                $this->template->assign('body', $value['body']);
                
                $this->template->assign('id', $id);
                
            }
            if($error)
            {
                echo("<script>alert('Falsche ID oder sie haben keine Berechtigungen diesen Eintrag anzusehen'); window.open('/Overview/showall','_self');</script>");
            }
       }
    }
    function delete($id)
    {
        $this->path = "delete";
        if(isset($id))
       {
           
            $params = array("id" => $id, "userid" => $_SESSION["user"]);
            $stm = parent::$sql->query($params);
            $error = true;
            foreach($stm as $key => $value)
            {
                $error = false;
                $tag = "";
                $kat = "";
                
                $tagsqli = new TagQueryBuilder();
                $katsqli = new KategorieQueryBuilder();
        
                $paramtag = array("tagid" => $value['ftagid'], "userid" => $_SESSION["user"]); 
                $paramkat = array("id" => $value['fkategorieid'], "userid" => $_SESSION["user"]);

                $taglist2 = $tagsqli->query($paramtag);
                $katlist2 = $katsqli->query($paramkat);
        
                foreach($taglist2 as $key => $value2)
                {
                    $tag = $value2['tagname'] ;
                }
                foreach($katlist2 as $key => $value3)
                {
                    $kat = $value3['kategorie'];
                }
                $this->template->assign('tag', $tag);
                $this->template->assign('kat', $kat);
                $this->template->assign('nummer', $value['nummer']);
                $this->template->assign('titel', $value['betreff']);
                $this->template->assign('date', $value['datum']);
                $this->template->assign('body', $value['body']);
                $this->template->assign('id', $id);
                
            }
            if($error)
            {
                echo("<script>alert('Falsche ID oder sie haben keine Berechtigungen diesen Eintrag zu löschen'); window.open('/Overview/showall','_self');</script>");
            }
       }
       
    }
    function deletefinally($id)
    {
        $this->path = "delete";
        
        $set = array("deleted" => 1);
        $filter = array("id" => $id, "userid" => $_SESSION["user"]);
        $stm = parent::$sql->update($set, $filter);
        echo("<script>alert('Eintrag gelöscht!'); window.open('/Overview/showall','_self');</script>");
       
    }
    

    function render()
    {
        parent::renderpath($this->path);
    }

    
    
}

?>