<?php
namespace M151;
use M151\Template;

class Overview extends Controller
{
    
    function __construct($name) 
    {
        parent::__construct();
        parent::$sql = new OverviewQueryBuilder();
    
    }

    function showall()
    { 
        $html = "";          
        
        $params = array("deleted" => 0, "userid" => $_SESSION['user']);
        $stm = parent::$sql->query($params);
       
        foreach ($stm as $value) {
        
            $tagsql = new TagQueryBuilder();
            $katsql = new KategorieQueryBuilder();
            
            $tagparams = array("tagid" => $value['ftagid'], "userid" => $_SESSION["user"]);
            $katparams = array("id" => $value['fkategorieid'], "userid" => $_SESSION["user"]);

            $taglist = $tagsql->query($tagparams);
            $katlist = $katsql->query($katparams);
            $tag = "";
            $kat = "";
            foreach($taglist as $key => $value1)
            {
                $tag = $value1['tagname'];
            }
            foreach($katlist as $key => $value2)
            {
                $kat = $value2['kategorie'];
            }

            $html = $html . "
            <tr onclick='goto(".$value['id'].")'>
                <td scope='row'><img class='pb' src='/images/". $_SESSION["pb"] ."'/></td>
                <td scope='row'>". $value['nummer'] ."</td>
                <td>". $value['betreff'] ."</td>
                <td>". $value['datum'] ."</td>
                <td>$tag</td>
                <td>$kat</td>
            </tr>";
        }
        $this->template->assign('journale', $html);

        
        $this->template->assign('nav', file_get_contents('../src/views/navigation.html'));
    }

    function render()
    {
        parent::renderpath('overview');
    }

    
    
}

?>