<?php
namespace M151;
use M151\Template;

class Einstellungen extends Controller
{
    public $path = "tag";
    function __construct() 
    {
        parent::__construct();
       
        $this->template->assign('nav', file_get_contents('../src/views/navigation.html'));
    }
    function deletetag($id)
    {
        parent::$sql = new TagQueryBuilder();
        if(isset($id))
        {
            $this->path = "tag";
            
            $filter = array("tagid" => $id, "userid" => $_SESSION["user"]); 
            $stm = parent::$sql->delete($filter);
            echo("<script>alert('Tag gelöscht!'); window.open('/Einstellungen/tag','_self');</script>");
        }
        else
        {
            header("Location: /Einstellungen/tag");
        }
    }
    function createtag()
    {
        parent::$sql = new TagQueryBuilder();
        $this->path = "tag";
        
        if(isset($_POST['tagname']))
        {
            $tagname = $_POST['tagname'];
            $userid = $_SESSION['user'];
            $columns = "tagid, tagname, userid";
            $values = array(null, $tagname, $userid);
            $stm = parent::$sql->insert($columns, $values);
            echo("<script>alert('Tag gespeichert')</script>");
            echo("<script>window.open('/Einstellungen/tag','_self');</script>");
        }
        else
        {
            header("Location: /Einstellungen/tag");
        }
        
    }
    function tag()
    {
        parent::$sql = new TagQueryBuilder();
        $this->path = "tag";
        $params = array("userid" => $_SESSION['user']);
        $html = "";                                                                                          
        $stm = parent::$sql->query($params);
       
        foreach ($stm as $value) {
        
            $html = $html . "<tr>
            <td scope='row'>".$value['tagname']."</td>
            <td><a href='/Einstellungen/deletetag/".$value['tagid']."'><i class='fas fa-trash'></i></a></td></tr>";
        }
        $this->template->assign('tags', $html);
    }
    function createkategorie()
    {
        parent::$sql = new KategorieQueryBuilder();
        $this->path = "tag";
        
        if(isset($_POST['kategoriename']))
        {
            $katname = $_POST['kategoriename'];
            $userid = $_SESSION['user'];
            $columns = "id, kategorie, userid";
            $values = array(null, $katname, $userid);
            $stm = parent::$sql->insert($columns, $values);
            echo("<script>alert('Kategorie gespeichert')</script>");
            echo("<script>window.open('/Einstellungen/kategorie','_self');</script>");
        }
        else
        {
            header("Location: /Einstellungen/kategorie");
        }
        
    }
    function deletekategorie($id)
    {
        parent::$sql = new KategorieQueryBuilder();
        if(isset($id))
        {
            $this->path = "kategorie";
            $filter = array("id" => $id, "userid" => $_SESSION["user"]); 
           
            $stm = parent::$sql->delete($filter);
            echo("<script>alert('Kategorie gelöscht!'); window.open('/Einstellungen/kategorie','_self');</script>");
        }
        else
        {
            header("Location: /Einstellungen/tag");
        }
    }
    function kategorie()
    {
        parent::$sql = new KategorieQueryBuilder();
        $this->path = "kategorie";
        $params = array("userid" => $_SESSION['user']);
        $html = "";                                                                                          
        $stm = parent::$sql->query($params);
       
        foreach ($stm as $value) {
        
            $html = $html . "<tr>
            <td scope='row'>".$value['kategorie']."</td>
        <td><a href='/Einstellungen/deletekategorie/".$value['id']."'><i class='fas fa-trash'></i></a></td></tr>";
        }
        $this->template->assign('kategorien', $html);


    }
    
    function render()
    {
        parent::renderpath($this->path);
    }

    
    
}

?>