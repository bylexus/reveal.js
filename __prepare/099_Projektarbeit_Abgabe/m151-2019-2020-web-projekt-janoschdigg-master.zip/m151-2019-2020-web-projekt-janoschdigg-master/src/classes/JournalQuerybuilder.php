<?php
namespace M151;

class JournalQueryBuilder extends QueryBuilder
{
    function __construct() 
    {
        parent::__construct();
    }

    public function getTable()
    {
        return "journal";
    }

    public function getColumns()
    {
        return "*";
    }

    public function query($params)
    {
        return parent::query($params);

    }

    public function insert($columns, $values)
    {
        return parent::insert($columns, $values);

    }
    public function update($set, $filter)
    {
        return parent::update($set, $filter);

    }
    public function delete($filter)
    {
        return parent::delete($filter);

    }
}

?>