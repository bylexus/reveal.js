<?php
 $this->dbhost = 'localhost';
 $this->dbname = 'Lernjournal'; //Ersetzten durch Datenbank name
 $this->dbuser = 'root';
 $this->dbpass = '';
?>