-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 08. Jan 2020 um 20:33
-- Server-Version: 10.4.6-MariaDB
-- PHP-Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `Lernjournal`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `benutzer`
--

CREATE TABLE `benutzer` (
  `id` int(11) NOT NULL,
  `login` varchar(100) NOT NULL,
  `passwort` varchar(256) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `vorname` varchar(100) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `Profile` text NOT NULL,
  `admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `benutzer`
--

INSERT INTO `benutzer` (`id`, `login`, `passwort`, `name`, `vorname`, `email`, `Profile`, `admin`) VALUES
(5, 'janosch', '918575fcfa784d68988bf4d31ac8c28015f0cff61c2fc152b25f0bdf937474df', 'Diggelmann', 'Janosch', 'janosch.diggelmann@gmail.com', '5e16006b8458e.jpeg', 1),
(6, 'admin', 'd32fd530119b149bdc3f1ed197baefac418428d349eba2fa983afb3fa5fb60d2', 'Administrator', 'Admin', 'admin@admin.ch', 'default.jpg', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `journal`
--

CREATE TABLE `journal` (
  `id` int(11) NOT NULL,
  `nummer` text NOT NULL,
  `betreff` text NOT NULL,
  `body` text NOT NULL,
  `userid` int(11) NOT NULL,
  `datum` text NOT NULL,
  `deleted` int(11) NOT NULL,
  `ftagid` int(11) NOT NULL,
  `fkategorieid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `journal`
--

INSERT INTO `journal` (`id`, `nummer`, `betreff`, `body`, `userid`, `datum`, `deleted`, `ftagid`, `fkategorieid`) VALUES
(14, 'LJ_0001', 'Mein erstes Journal', '<h2>Hallo Welt</h2>\r\n\r\n<p>Das ist mein erstes Journal</p>\r\n', 5, '06.01.2020', 0, 8, 3),
(15, 'LJ_0002', 'Wie erstelle ich ein Journal', '<p>Im Nav auf Erstellen Klicken dann Sachen eingeben und speichern klicken.</p>\r\n', 5, '06.01.2020', 0, 6, 2),
(16, 'LJ_0003', 'Journal mit Tags', '<p>Test tutorial mit Tags</p>\r\n', 5, '06.01.2020', 0, 7, 3),
(17, '123', '123', '<p>123</p>\r\n', 6, '06.01.2020', 1, 0, 0),
(18, 'LJ_1111', 'AdminJournal', '<p>asd</p>\r\n', 6, '07.01.2020', 0, 0, 0),
(19, 'LJ_9999', 'Das ist mein Journal Janosh Diggelmann', '<p>asd</p>\r\n', 5, '08.01.2020', 1, 6, 1),
(20, 'LJ_1111', 'Testerstellen', '<p>yxc</p>\r\n', 5, '08.01.2020', 1, 9, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kategorie`
--

CREATE TABLE `kategorie` (
  `id` int(11) NOT NULL,
  `kategorie` text NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `kategorie`
--

INSERT INTO `kategorie` (`id`, `kategorie`, `userid`) VALUES
(3, 'Checkliste', 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tag`
--

CREATE TABLE `tag` (
  `tagid` int(11) NOT NULL,
  `tagname` text NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `tag`
--

INSERT INTO `tag` (`tagid`, `tagname`, `userid`) VALUES
(6, 'Arbeit', 5),
(7, 'Privat', 5),
(8, 'BMS', 5),
(9, 'Test1', 5);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Indizes für die Tabelle `journal`
--
ALTER TABLE `journal`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`tagid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT für Tabelle `journal`
--
ALTER TABLE `journal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT für Tabelle `kategorie`
--
ALTER TABLE `kategorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `tag`
--
ALTER TABLE `tag`
  MODIFY `tagid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
