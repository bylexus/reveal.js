------------------------------------------------
Database
------------------------------------------------
1. Create Database "Lernjournal"
2. Execute lernjournal.sql


------------------------------------------------
Bedienung
------------------------------------------------
- Vorhandene User:
    - janosch (pw: banane)
    - admin (pw: admin)