<?php
/*

Code um User zu erstellen
anything' OR 1 = 1;  INSERT INTO users(id, username, password) VALUES (null,'Max','Muster'); # 

Nur Login
anything' OR 1 = 1; #

*/

    $dbcon = new \PDO("mysql:host=localhost;dbname=test","root", "");
    $login = false;
    $gesetzt = false;

    if(isset($_GET['unsicher']))
    {
        $gesetzt = true;
        if(isset($_GET['user']))
        {
            $user = $_GET['user'];
            $pass = $_GET['password'];

            $sql = $dbcon->prepare("Select * from users where username = '$user' AND password = '$pass'");
            $sql->execute();
            $data = $sql->fetchAll();
            foreach($data as $key => $value)
            {
                    $login = true;
            }
            
        }
    }

    if(isset($_GET['sicher']))
    {
        $gesetzt = true;
        if(isset($_GET['user']))
        {
            
            $user = $_GET['user'];
            $pass = $_GET['password'];
            
            $sql = $dbcon->prepare("SELECT username, password from users where username = ? AND password = ?");
            $sql->execute(array($user, $pass));
            $data = $sql->fetchAll();
            var_dump($data);
             foreach($data as $key => $value)
            {
                    $login = true;
            
            }   
            
            
        }
    }
    
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="src/classes/injection.css">
    <title>Injection</title>
</head>
<body><br>
<h1>SQL Injection Demo</h1>
<br><br>
    <div class="banner">
        <?php
        if($login)
        {
            echo "
            <div class='alert alert-primary' role='alert'>
            Hallo $user
            </div>
            ";
        }
        else if($gesetzt)
        {
            echo "
            <div class='alert alert-danger' role='alert'>
            Login Fehlgeschlagen
            </div>
            ";
        }
        ?>
    </div>
    <div class="left">
        <form action = "/" method="GET">
            <h1>Unsicher</h1>
            <div class="form-group">
                <label for="user">Benutzername</label>
                <input type="Text" class="form-control" id="user" name="user" placeholder="Chuck Norris">
            </div>
            <div class="form-group">
                <label for="pass">Passwort</label>
                <input type="Text" class="form-control" name="password" id="pass" placeholder="Banane22">
            </div>
            <button type="submit" name="unsicher" class="btn btn-block btn-danger">Log In</button>
            <br><br>
            <code>
                $sql = $dbcon->prepare("Select * from users where username = '$user' AND password = '$pass'");<br>
                $sql->execute();<br>
                $data = $sql->fetchAll();
            </code>
        </form>
    </div>
    <div class="right">
        
    <form action = "/" method = "GET">
            <h1>Sicher</h1>
            <div class="form-group">
                <label for="user">Benutzername</label>
                <input type="Text" class="form-control" id="user" name="user" placeholder="Chuck Norris">
            </div>
            <div class="form-group">
                <label for="pass">Passwort</label>
                <input type="Text" class="form-control" name="password" id="pass" placeholder="Banane22">
            </div>
            <button type="submit" name="sicher" class="btn btn-block btn-primary">Log In</button>
            <br><br>
            <code>
            $sql = $dbcon->prepare("SELECT username, password from users where username = ? AND password = ?");<br>
            $sql->execute(array($user, $pass));<br>
            $data = $sql->fetchAll();
            </code>
        </form>
    </div>
   
</body>
</html>


<style>
@import url('https://fonts.googleapis.com/css?family=Lato&display=swap');
*{
    font-family: 'Lato', sans-serif;
}
h1{
    text-align: center;
}
form{
    padding-top: 100px !important;
    padding: 50px;
}
.left{
    position: absolute;
    width: 50%;
    height: 100%;
    left: 0;
    top: 75px;
    
}
.right{
    position: absolute;
    width: 50%;
    height: 100%;
    right: 0;
    top: 75px;
}
.banner{
    position: fixed;
    width: 95%;
    top: 100px;
    left: 2.5%;
}
</style>


