 <?php
# lade composer autoloader:
require_once __DIR__ . '/../vendor/autoload.php';
include('/Users/janosch/GitHub/M151/src/head.html');

$con = new M151\Connection();


try{
    $controller = "";
    $action = "";
    $param = "";
    if(!isset($_SERVER['PATH_INFO']))
    {
        header('Location: /Home');
    }
    $exploded = explode('/', $_SERVER['PATH_INFO']);
   
        if(isset($exploded[1]))
        {
            $controller = $exploded[1];
        }
        if(isset($exploded[2]))
        {
            $action = $exploded[2];
        }
        if(isset($exploded[3]))
        {
            $param = $exploded[3];
        }
    
    
    
}catch(Throwable $e)
{
    header('Location: /Home');
}
if($controller != "images")
{
    $controllerName =  "M151\\" . $controller;
    $actionName = $action;
    $params = $_REQUEST;
    
    try{
            $controllerInstanz = new $controllerName($params);
            if($action != '' && $param == "")
            {
                $controllerInstanz->$action();
            }
            else if($action != '' && $param != "")
            {
                $controllerInstanz->$action($param);
            }
            $controllerInstanz->render();
    } catch(Throwable $e)
    {
        print($e);
    //   header('Location: /Home');
    }
}
else
{
   
}

?>

