<?php
use M151\Application;
use M151\Router;

# lade composer autoloader:
require_once __DIR__ . '/../vendor/autoload.php';

# Definiere Routen:
Router::get('/', 'M151\Controller\DefaultController', 'index');
Router::any('/demo', 'M151\Controller\DefaultController', 'demo');
Router::any('/dbtest', 'M151\Controller\DefaultController', 'dbtest');

# Formular-Demo-Routen:
Router::get('/form/show', 'M151\Controller\FormController', 'getForm');
Router::get('/form/linkResult', 'M151\Controller\FormController', 'linkResult');
Router::post('/form/result', 'M151\Controller\FormController', 'postForm');

# Login-Formular-Routen:
Router::get('/login', 'M151\Controller\LoginController', 'loginForm');
Router::post('/login_try', 'M151\Controller\LoginController', 'loginTry');

# Übergebe an Applikation:
$app = Application::getInstance();
$app->start();
