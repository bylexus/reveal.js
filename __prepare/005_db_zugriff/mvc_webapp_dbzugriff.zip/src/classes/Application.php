<?php

namespace M151;

use M151\Http\Request;

class Application
{
    private static $_inst;
    private $_dbConn;

    public $request = null;
    public $controller = null;
    public $routeInfo = null;

    private function __construct()
    {
        $this->request = new Request($_REQUEST, $_SERVER);
    }

    public static function getInstance()
    {
        if (!static::$_inst) {
            static::$_inst = new Application();
        }
        return static::$_inst;
    }

    public function start()
    {
        $routeInfo = Router::findRouteInfo($this->request);
        $controller = Router::getRouteController($routeInfo);
        $this->controller = $controller;
        $this->routeInfo = $routeInfo;
        $actionFn = $routeInfo['action'];
        $ret = $controller->$actionFn($this->request);
    }

    public function routeUrl($url)
    {
        $requestUri = preg_replace('/\?.*/', '', $_SERVER['REQUEST_URI']);
        $routePath = $_SERVER['PATH_INFO'];
        return $this->str_lreplace($routePath, '', $requestUri) . $url;

    }

    protected function str_lreplace($search, $replace, $subject)
    {
        $pos = strrpos($subject, $search);
        if ($pos !== false) {
            $subject = substr_replace($subject, $replace, $pos, strlen($search));
        }
        return $subject;
    }

    public function dbConn()
    {
        if (!$this->_dbConn) {
            // DB Parameter definieren:
            $dsn = 'mysql:host=db;port=3306;dbname=m151';
            $username = 'm151';
            $password = 'm151';
            $options = array(
                // Wichtig: damit die Daten als utf-8 codierte Strings geliefert werden
                \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
            );

            // Datenbankverbindung aufbauen:
            $dbh = new \PDO($dsn, $username, $password, $options);

            if ($dbh) {
                $this->_dbConn = $dbh;
            }
        }
        return $this->_dbConn;
    }
}
