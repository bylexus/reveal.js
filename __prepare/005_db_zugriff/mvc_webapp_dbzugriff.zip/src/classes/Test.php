<?php
namespace M151;

class Test
{
    public function hello()
    {
        echo "Hello, World! From " . \get_class($this);
    }
}
