<?php
namespace M151\Controller;

use M151\Application;

class Controller {
    public function __construct() {
    }

    public function routeUrl($url) {
        return Application::getInstance()->routeUrl($url);
    }

    public function redirectTo($routeUrl) {
        header('Location: '.$this->routeUrl($routeUrl));
    }

}
