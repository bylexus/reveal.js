<?php
namespace M151\Controller;

use M151\Application;
use M151\Http\Request;
use M151\View\View;

class LoginController extends Controller
{
    /**
     * Ein HTML-Formular ausliefern
     */
    public function loginForm(Request $req)
    {
        $error = false;
        if ($req->getParam('failed')) {
            $error = 'Login-Fehler!';
        }
        $view = new View('login-form.html');
        $view->assign('error', $error);
        $view->render();
    }

    /**
     * Login überprüfen, Formulardaten von /login form
     */
    public function loginTry(Request $req)
    {
        $username = $req->getParam('login');
        $pw = $req->getParam('passwort');
        $dbConn = Application::getInstance()->dbConn();

        // PDOStatement erstellen: Query senden:
        $stm = $dbConn->query("SELECT * FROM benutzer WHERE login = '{$username}' AND passwort = '{$pw}'");
        // PDOStatement auslesen: fetch() holt den nächsten Record, fetchAll() holt alle Records:
        $result = $stm->fetch(\PDO::FETCH_ASSOC);

        // Ausgabe des Resultats:
        if ($result) {
            $updateQuery = "UPDATE benutzer SET letzter_login = now() WHERE id = {$result['id']}";
            $res = $dbConn->exec($updateQuery);
            $lastLogin = null;
            if ($res) {
                $readQuery = "SELECT * FROM benutzer WHERE id = {$result['id']}";
                $result = $dbConn->query($readQuery)->fetch();
                $lastLogin = $result['letzter_login'];
            }
            echo "<div style='background-color: green; padding: 1em;'>Hallo, {$result['vorname']}! Dein letzter Login wurde festgehalten: {$lastLogin}</div>";
            echo "<table>";
            echo "<tr><td>ID</td><td>{$result['id']}</td></tr>";
            echo "<tr><td>Name</td><td>{$result['name']}</td></tr>";
            echo "<tr><td>Vorname</td><td>{$result['vorname']}</td></tr>";
            echo "<tr><td>Email</td><td><a href='mailto:{$result['email']}'>{$result['email']}</a></td></tr>";
            echo "</table>";
            echo "<a href='{$this->routeUrl('/login')}'>Zur&uuml;ck zum Login</a>";
        } else {
            // oder wieder zum Login, wenn fehlgeschlagen:
            $this->redirectTo('/login?failed=true');
        }
    }
}
