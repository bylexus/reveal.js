<?php
namespace M151\Controller;

use M151\Http\Request;
use M151\View\View;

class DefaultController extends Controller
{
    public function index(Request $req)
    {
        header('Content-Type: text/plain');
        echo "Route: {$req->urlRoute}\n";
        foreach ($req->getParams() as $key => $value) {
            echo "Param: {$key} => {$value}\n";
        }
    }

    public function demo(Request $req)
    {
        $view = new View('default-demo.html');
        $view->assign('route', $req->urlRoute);
        $view->assign('params', $req->getParams());
        $view->render();
    }

    public function dbtest(Request $req)
    {
        $dsn = 'mysql:host=db;port=3306;dbname=m151';
        $username = 'm151';
        $password = 'm151';
        $options = array(
            // Wichtig: damit die Daten als utf-8 codierte Strings geliefert werden
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );

        $dbh = new \PDO($dsn, $username, $password, $options);

        if ($dbh) {
            echo "Erfolg! Datenbankverbindung hergestellt";
        }
        // $dbh ist ein Objekt der Klasse PDO (siehe http://php.net/manual/en/book.pdo.php)
        return $dbh;
    }
}
