<?php
namespace M151\Controller;

use M151\Http\Request;
use M151\View\View;

class FormController extends Controller {
    /**
     * Ein HTML-Formular ausliefern
     */
    public function getForm(Request $req) {
        $error = $req->getParam('error', null);
        // Der Einfachheit halber geben wir hier das HTML direkt aus (ohne ein View-Script zu erstellen):
        $view = <<<EOT
<html>
<body>
    <h1>Link-Aufrufe mit URL-Parametern:</h1>
    <a href="linkResult?name=Alex&foo=bar">Klick mich! Link: linkResult?name=Alex&foo=bar</a>

    <h1>Formulardaten via POST:</h1>
    <form action="result" method="POST">
        <label>Name: <input type="text" name="name"></label>
        <label>Geschlecht:
            <select name="geschlecht">
                <option value="maennlich">M&auml;nnlich</option>
                <option value="weiblich">Weiblich</option>
            </select>
        </label>
        <label>Newsletter? <input type="checkbox" name="newsletter" value="true"></label>
        <button type="submit">Absenden</button>
    </form>
    {$error}
</body>
</html>
EOT;
        echo $view;
    }

    /**
     * HTML-Formulardaten auslesen / verarbeiten
     */
    public function postForm(Request $req) {
        // Auslesen der POST-Parameter, "the PHP Way":
        $name= $_POST['name'] ?? null;
        $geschlecht = $_POST['geschlecht'] ?? null;
        $nl = $_POST['newsletter'] ?? null;

        // Oder via Framework-Funktionen:
        $name= $req->getParam('name');
        $geschlecht = $req->getParam('geschlecht');
        $nl = $req->getParam('newsletter');

        echo "Eingaben: Name: {$name}, Geschlecht: {$geschlecht}, Newlsetter: ${nl}";
    }

    /**
     * HTML-Parameter auslesen / verarbeiten
     */
    public function linkResult(Request $req) {
        // Auslesen der GET-Parameter, "the PHP Way":
        $name= $_GET['name'];
        $foo = $_GET['foo'];

        // Oder via Framework-Funktionen:
        $name= $req->getParam('name');
        $foo = $req->getParam('foo');

        echo "Eingaben: Name: {$name}, foo: {$foo}";
    }
}
