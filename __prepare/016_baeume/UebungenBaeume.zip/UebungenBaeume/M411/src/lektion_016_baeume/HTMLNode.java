package lektion_016_baeume;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class HTMLNode {
	String tag;
	Map<String, String> attribute = new HashMap();
	List<HTMLNode> kindknoten = new LinkedList<>();
	
	public HTMLNode(String tag, Map<String, String> attribute, List<HTMLNode> kinder) {
		this.tag = tag;
		if (attribute != null) {
			this.attribute = attribute;
		}
		if (kinder != null) {
			this.kindknoten = kinder;
		}
	}
	
	/**
	 * Fügt einen neuen Kindknoten ein
	 */
	public void add(HTMLNode kind) {
		this.kindknoten.add(kind);
	}
	
	public void print(int einruecken) {
		// Einrückung generieren:
		String einr = "";
		for (int i = 0; i < einruecken; i++) {
			einr += " ";
		}
		
		// Beginn-Tag ausgeben: Wenn keine Kinder, dann ist es eine Text-Node,
		// sonst ein Tag:
		if (!this.kindknoten.isEmpty()) {
			String s = "<" + this.tag;
			
			// Attribute sind Teil des Beginn-Tags:
			for (Map.Entry<String, String> attr : this.attribute.entrySet()) {
				s += " " + attr.getKey() + "=\"" + attr.getValue() + "\"";
			}
			s += ">";
			System.out.println(einr + s);
			
			// Inhalt (Kinder) ausgeben: rekursiv alle Kinder ausgeben:
			for (HTMLNode kind : this.kindknoten) {
				kind.print(einruecken + 4);
			}
			
			// End-Tag ausgeben:
			System.out.println(einr + "</" + this.tag + ">");
			
		} else {
			// Dies ist nur eine Text-Node, also nur "tag" (=text) ausgeben:
			System.out.println(einr + this.tag);
		}
	}
}
