package lektion_016_baeume;

/**
 * Beispiel: Umsetzen eines Termbaumes für den Term (((3+4)*5)+(2*3))
 */
public class TermBaumMain {

	public static void main(String[] args) {
		// Wir füllen den Term in den Baum ab, in dem wir die einzelnen
		// Nodes erzeugen und zusammenhängen:
		TreeNode n3_3 = new TreeNode("3", null, null);
		TreeNode n3_4 = new TreeNode("4", null, null);
		TreeNode n2_plus = new TreeNode("+", n3_3, n3_4);
		TreeNode n2_5 = new TreeNode("5", null, null);
		TreeNode n2_mal = new TreeNode("*", n2_plus, n2_5);
		TreeNode n2_2 = new TreeNode("2", null, null);
		TreeNode n2_3 = new TreeNode("3", null, null);
		TreeNode n1_mal = new TreeNode("*", n2_2, n2_3);
		// Die root node erstellen wir als letztes:
		TreeNode root = new TreeNode("+", n2_mal, n1_mal);
		
		// Nun laufen wir durch den Baum, um die Ausgabe zu erzeugen
		// (siehe class BaumLogik):
		TermBaumLogik l = new TermBaumLogik();
		String formel = l.walkFormula(root);
		System.out.println(formel);
		
		
		// ... oder wir rechnen das Ergebnis aus:
		Double ergebnis = l.calcFormula(root);
		System.out.println("Ergebnis: "+ergebnis);
		
		
		// -----------------------------------------------------------
		//         Alternative Füll-Variante für Formeln
		// -----------------------------------------------------------
		// Ich fülle hier den Baum nochmals neu - dieses Mal unter
		// Zuhilfenahme der RPN - Umgekehrt Polnische Notation, 
		// siehe https://en.wikipedia.org/wiki/Reverse_Polish_notation.
		// --> Dies ist einfacher als oben, oder?
		String[] formelRPN = {"3","4","+","5","*","2","3","*","+"};
		root = l.fillRPN(formelRPN);
		formel = l.walkFormula(root);
		System.out.println(formel);
	}
}
