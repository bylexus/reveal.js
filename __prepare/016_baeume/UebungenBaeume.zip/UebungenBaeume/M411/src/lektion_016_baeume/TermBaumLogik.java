package lektion_016_baeume;

import java.util.Arrays;
import java.util.Stack;

/**
 * Kapselt die Logik rund um den Baum - traversieren etc. 
 */
public class TermBaumLogik {
	
	/**
	 * Durchläuft den Baum (L-R-W, Postorder), und formt den
	 * Formel-String.
	 * @param root Die root-Node des Baumes
	 * @return  der fertige Formel-String
	 */
	public String walkFormula(TreeNode root) {
			// Ist die aktuelle Node ein Blatt? Dann geben wir den Wert zurück:
			if (root.left == null || root.right == null) {
				return root.data;
			}
			// Sonst lassen wir den linken und rechten Teil rekursiv durchlaufen:
			String links = this.walkFormula(root.left);
			String rechts = this.walkFormula(root.right);
			return String.format("(%s %s %s)", links, root.data, rechts);
	}
	
	/**
	 * Wie auch walkFormula durchläuft den Baum (L-R-W, Postorder), und berechnet
	 * jeweils linker/rechter Teilbaum, dann verknüpft das Ergebnis mit dem Operator.
	 * @param root Die root-Node des Baumes
	 * @return  der fertige Formel-String
	 */
	public Double calcFormula(TreeNode root) {
		// Ist die aktuelle Node ein Blatt? Dann geben wir den Wert zurück:
		if (root.left == null || root.right == null) {
			return Double.parseDouble(root.data);
		}
		// Sonst lassen wir den linken und rechten Teil rekursiv durchlaufen und ausrechnen:
		Double links = this.calcFormula(root.left);
		Double rechts = this.calcFormula(root.right);
		switch (root.data) {
			case "+": return links + rechts;
			case "-": return links - rechts;
			case "*": return links * rechts;
			case "/": return links / rechts;
			default:
				System.out.println("Ooops! Unbekannter Operator!");
				return -1.0;
		}
	}
	
	public boolean istOperator(String element) {
		String[] operatoren = {"*","+","-","/"};
		return Arrays.binarySearch(operatoren, element) >= 0;
	}
	
	/**
	 * Füllt den Baum mit der Umgekehrt Polnischen Notation
	 * (RPN, Reversed Polish notation, siehe https://en.wikipedia.org/wiki/Reverse_Polish_notation):
	 * 
	 *  Als Eingabe wird ein Array von Strings geliefert, welche in umgekehrt polnischer Notations-
	 *  Reihenfolge geordnet sind.
	 *  
	 *  Die Elemente werden dann nach und nach mittels eines Stack in einen Baum überführt.
	 * @param data
	 * @return die root-Node des Baumes
	 */
	public TreeNode fillRPN(String[] data) {
		
		Stack<TreeNode> stack = new Stack<>();
		
		for (String element : data) {
			// Ist das aktuelle Element im Input-Array ein Operator?
			if (this.istOperator(element)) {
				// Ja: Wir erstellen eine neue Node mit dem Operator und
				// 2 Elementen auf dem Stack:
				if (stack.size() < 2) {
					System.out.println("Ooops! RPN-Notation falsch!");
					return null;
				}
				TreeNode rechts = stack.pop();
				TreeNode links = stack.pop();
				TreeNode root = new TreeNode(element, links, rechts);
				// ... und packen die neue Node wieder auf den Stack.
				stack.push(root);
			} else {
				// Nein: wir haben eine Zahl. Die kommt als TreeNode auf den Stack.
				stack.push(new TreeNode(element,null,null));
			}
		}
		
		// Jetzt dürfte nur noch 1 Element auf dem Stack sein: die root-Node.
		if (stack.size() > 1) {
			System.out.println("Ooops! Überzählige Elemente! RPN-Notation falsch!" + stack.size());
			return null;
		}
		return stack.pop();
	}
}
