package lektion_016_baeume;

public class EinfacherBaum {

	public static void main(String[] args) {
		// Schritt 1: alle Knoten OHNE Verknüpfung erstellen: 
		TreeNode alpha = new TreeNode("alpha", null, null);
		TreeNode bravo = new TreeNode("bravo", null, null);
		TreeNode charlie = new TreeNode("charlie", null, null);
		TreeNode delta = new TreeNode("delta", null, null);
		TreeNode echo = new TreeNode("echo", null, null);
		TreeNode foxtrott = new TreeNode("foxtrott", null, null);
		TreeNode golf = new TreeNode("golf", null, null);
		
		// Schritt 2: Knoten zu einem Baum zusammenhängen:
		delta.left = bravo;
		delta.right = foxtrott;
		
		bravo.left = alpha;
		bravo.right = charlie;
		
		foxtrott.left = echo;
		foxtrott.right = golf;
		
		// Schritt 3: Ausgabe und Zählen damit wir den ganzen Baum durchlaufen,
		// beginnen wir bei der Wurzel:
		System.out.println("Baum-Inhalt in Reihenfolge:");
		delta.inorderPrint();
		
		System.out.println("Anzahl Elemente: " + delta.count());
	}
}
