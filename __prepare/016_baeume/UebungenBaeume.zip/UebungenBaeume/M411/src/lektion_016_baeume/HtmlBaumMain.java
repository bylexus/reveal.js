package lektion_016_baeume;

import java.util.HashMap;
import java.util.Map;

public class HtmlBaumMain {

	/**
	 * Zeigt den Aufbau und Ausgabe eines HTML-Dokuments
	 */
	public static void main(String[] args) {
		// HTML-Baum aufbauen:
		// oberste node: html:
		HTMLNode html = new HTMLNode("html", null, null);
		HTMLNode body = new HTMLNode("body", null, null);
		html.add(body);
		
		HTMLNode h1 = new HTMLNode("h1", null, null);
		h1.add(new HTMLNode("Hello, World!", null, null));
		HTMLNode p1 = new HTMLNode("p", null, null);
		HTMLNode p2 = new HTMLNode("p", null, null);
		p1.add(new HTMLNode("Dies ist ein Absatz. Er setzt sich von anderen Absätzen ab.", null, null));
		
		HTMLNode text1 = new HTMLNode("Hier kommt ein Link: ", null, null);
		
		// Der Link ist etwas komplizierter: Wir müssen die Attribute auch noch definieren:
		HTMLNode linktext = new HTMLNode("Wikipedia DE", null, null);
		Map<String, String> linkAttribute = new HashMap<>();
		linkAttribute.put("href", "https://wikipedia.de");
		HTMLNode link = new HTMLNode("a", linkAttribute, null);
		// ... UND den Linktext als Kindknoten anhängen:
		link.add(linktext);
		
		p2.add(text1);
		p2.add(link);
		
		body.add(h1);
		body.add(p1);
		body.add(p2);
		
		// Wow... Das ist eine Menge Code für so ein bisschen HTML!
		// Solche Strukturen baut man normalerweise ja auch nicht von Hand.
		
		// Dafür ist die Ausgabe um so einfacher:
		html.print(0);
	}
}
