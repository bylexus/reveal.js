package lektion_016_baeume;

public class TreeNode {
	public TreeNode left;
	public TreeNode right;
	String data;
	
	public TreeNode(String data, TreeNode left, TreeNode right) {
		this.data = data;
		this.left = left;
		this.right = right;
	}
	
	/**
	 * Aufgabe Einfacher Baum 1: inorder-Print-Methode
	 * 
	 * inorderPrint muss auf der Wurzel-Node aufgerufen werden:
	 * diese gibt dann die Elemente rekursiv aus.
	 */
	public void inorderPrint() {
		// Reihenfolge der Ausgabe:
		// 1. linker Teilbaum (rekursiv)
		// 2. sich selber
		// 3. rechter Teilbaum (rekursiv)
		if (this.left != null) {
			this.left.inorderPrint();
		}
		System.out.println(this.data);
		if (this.right != null) {
			this.right.inorderPrint();
		}
	}
	
	/**
	 * Aufgabe Einfacher Baum 2: count()-Methode zählt alle Nodes,
	 * rekursiv ab der Wurzelnode
	 */
	public int count() {
		// Reihenfolge der Ausgabe:
		// hier nicht relevant, wichtig ist nur, dass alle Elemente "erwischt" werden.
		// die Grösse vom linken und rechten Teilbaum wird wiederum rekursiv ermittelt:
		int count = 1; // sich selber
		
		if (this.left != null) {
			count += this.left.count();
		}
		if (this.right != null) {
			count += this.right.count();
		}
		
		return count;
	}
}
