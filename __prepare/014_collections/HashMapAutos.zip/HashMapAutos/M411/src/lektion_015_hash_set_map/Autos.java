package lektion_015_hash_set_map;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Autos {

	public static void main(String[] args) {
		String[] autos = {
				"Skoda","Porsche","VW","BMW","Fiat","Ford","VW","VW","VW","VW","VW","Fiat","Fiat",
				"Skoda","Ford","Ford","Skoda","Fiat","VW","BMW","Porsche","Skoda","Ford","Ford",
				"Audi","Ford","Porsche","Audi","Fiat","Audi","Audi","BMW","VW","VW","VW","Renault",
				"BMW","VW","BMW","Fiat","BMW","Fiat","Fiat","Audi","VW","Porsche","VW","Fiat","BMW",
				"Renault","Ford","Ford","VW","Ford","BMW","Audi","Ford","Porsche","VW","VW","Ford",
				"VW","Ford","Ford","Fiat","Audi","Mercedes","Renault","Audi","VW","Renault","Audi",
				"VW","Ford","Audi","Renault","Audi","Audi","VW","VW","Audi","VW","VW","Ford","Audi",
				"VW","Ford","Ford","Audi","VW","Ford","Ford","Porsche","Fiat","BMW","Ford","Ford",
				"Fiat","Ford","VW","Fiat","VW","Porsche","Porsche","Ford","Ford","Ford","BMW","Ford",
				"Fiat","VW","Renault","Skoda","Audi","VW","VW","Ford","Audi","Audi","Ford","VW",
				"Renault","Ford","VW","Fiat","VW","Fiat","Fiat","Audi","Ford","Fiat","Porsche","BMW",
				"Audi","Skoda","Audi","Audi","VW","Mercedes","VW","BMW","VW","VW","Ford","Audi",
				"Porsche","VW","Renault","Porsche","VW","Ford","Renault","Fiat","Mercedes","Ford",
				"VW","Audi","VW","Fiat","Fiat","Renault","Fiat","VW","Skoda","Mercedes","Skoda",
				"Mercedes","Audi","VW","Ford","Ford","BMW","Ford","Renault","BMW","Fiat","Porsche",
				"Audi","Renault","Ford","Renault","Ford","Porsche","Audi","Fiat","Renault",
				"Porsche","Ford","Renault","VW"
		};
		List<String> autoList = Arrays.asList(autos);
		
		// Einfüllen in die Hash Map: Schlüssel ist die Automarke, Wert ist ein Zähler (Integer):
		Map<String, Integer> autoStat = new HashMap<>();
		for (String a : autoList) {
			Integer sum = autoStat.get(a);
			if (sum == null) {
				sum = 0;
			}
			if (autoStat.containsKey(a) == false) {
				autoStat.put(a, 0);
			}
			autoStat.put(a, sum + 1);
		}
		
		// Ausgeben der Statistik:
		// Map.Entry beinhaltet sowohl den Schlüssel wie auch den Wert
		// siehe https://docs.oracle.com/javase/8/docs/api/index.html?java/util/Map.Entry.html
		Map.Entry<String, Integer> max = null;
		Map.Entry<String, Integer> min = null;
		
		for (Map.Entry<String, Integer> e: autoStat.entrySet()) {
			// Ausgeben:
			System.out.println(e.getKey() + ": "+e.getValue());
			// min/max speichern:
			if (max == null || max.getValue() < e.getValue()) {
				max = e;
			}
			if (min == null || min.getValue() > e.getValue()) {
				min = e;
			}
		}
		
		System.out.println(max.getKey() + " hat die meisten Autos: " + max.getValue());
		System.out.println(min.getKey() + " hat die wenigsten Autos: " + min.getValue());
		
	}
}
