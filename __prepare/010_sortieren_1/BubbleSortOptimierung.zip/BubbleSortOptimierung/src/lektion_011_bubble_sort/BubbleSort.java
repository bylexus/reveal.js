package lektion_011_bubble_sort;

public class BubbleSort {

	public static void main(String[] args) {
		int[] zahlen = {16, 7, 9, 11, 5, 12, 10, 3, 13, 18, 6, 17, 15, 8, 19, 2, 4, 14, 1};
		BubbleSort sort = new BubbleSort();
		sort.print(zahlen);
		sort.bubbleSort(zahlen);
		sort.print(zahlen);

	}
	public void print(int[]daten) {
		for (int i : daten) {
			System.out.print(i + " ");
		}
		System.out.println();
	}
	
	// ohne Optimierung
	public void bubbleSort(int[] daten) {
		for (int n = daten.length; n > 1; n--) {
			for (int i = 0; i < n-1; i++) {
				if (daten[i] > daten[i+1]) {
					int tmp = daten[i];
					daten[i] = daten[i+1];
					daten[i+1] = tmp;
				}
			}
		}
	}
	
	// mit Optimierung: wir durchlaufen die innere Schlaufe nur nochmals,
	// wenn beim letzten Durchlauf noch ein Tausch stattfand: Ansonsten
	// ist die Liste schon sortiert, wir können aufhören.
	public void bubbleSortOpt(int[] daten) {
		for (int n = daten.length; n > 1; n--) {
			boolean getauscht = false;
			for (int i = 0; i < n-1; i++) {
				if (daten[i] > daten[i+1]) {
					int tmp = daten[i];
					daten[i] = daten[i+1];
					daten[i+1] = tmp;
					getauscht = true;
				}
			}
			if (getauscht != true) {
				return;
			}
		}
	}
}
