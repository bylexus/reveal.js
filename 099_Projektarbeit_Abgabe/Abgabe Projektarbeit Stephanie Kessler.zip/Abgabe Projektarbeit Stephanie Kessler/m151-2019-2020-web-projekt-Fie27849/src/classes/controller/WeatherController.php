<?php
namespace M151\controller;

use M151\model\WeatherModel;
use M151\view\WeatherView;
// Datei fürDB Zugriff einbinden
require_once("inc/db_config.inc.php");

class WeatherController {


	public function readJSONData($apiKey, $zip, $country) {
		// Daten als String von HTTP-API holen:
		$url = "http://api.openweathermap.org/data/2.5/weather?lang=de&units=metric&zip={$zip},{$country}&appid={$apiKey}";
		$response = file_get_contents($url);
		//file_put_contents('/temp/weather.txt', $response);
		// JSON-Antwort in Objekt konvertieren:
		$obj = json_decode($response);
		return $obj;
	}

	public function getWeather(){

		$weatherRaw = $this->readJSONData('20915fef33b0fb948cf25547fa3d5da6', '8500', 'ch');
		$weatherNice = new WeatherModel;
		$weatherNice->weatherRawToNice($weatherRaw, $weatherNice);

		$showWeather = new WeatherView;
		$showWeather->showWeather($weatherNice);


	}



}