<?php

function db_connect(){
	$dsn = 'mysql:host=db;dbname=m151';
	$username = 'root';
	$password = 'root';
	$options = array(
	    \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
	); 
	$dbh = new \PDO($dsn, $username, $password, $options);

	return($dbh);
}

function db_dump($dbh){
	print_r($dbh);
	print_r($dbh->query('select * from benutzer where id="1"')->fetchAll());
}


function db_getAllUsers($dbh){
	$stmnt = "SELECT * FROM benutzer";
	foreach ($dbh->query($stmnt) as $row) {
		echo "<br />" . $row['firstname']."<br />";
		echo $row['lastname']."<br />";
		echo $row['email']."<br />";
		echo $row['username']."<br />";
		echo $row['password']."<br />";
		echo $row['session_id']."<br />";
		echo $row['user_status']."<br /><br />";

	}
}

function db_getUserByLogin($dbh, $username){
	$stmnt = $dbh->prepare('SELECT * FROM benutzer WHERE username=?');
	$stmnt->execute(array($username));
	$userData = $stmnt->fetch();

	$user['firstname'] = $userData['firstname'];
	$user['lastname'] = $userData['lastname'];
	$user['email'] = $userData['email'];
	$user['username'] = $username;
	$user['password'] = $userData['password'];
	$user['session_id'] = $userData['session_id'];
	$user['user_status'] = $userData['user_status'];

	// For Debugging
	echo "<br />" . $user['firstname'] . ", " . $user['lastname'] . ", " . $user['email'] . ", " . $user['username'] . ", " . $user['password'] . $user['session_id'] . ", " . $user['user_status'] . ",";

	return($user);
}

// function db_addNewUser($dbh, $newUserData){
// 	$stmnt = $dbh->prepare('INSERT INTO benutzer (username, password, lastname, firstname, email) VALUES (?,?,?,?,?)');
// 	$firstname = $newUserData['firstname'];
// 	$lastname = $newUserData['lastname'];
// 	$email = $newUserData['email'];
// 	$username = $newUserData['username'];
// 	$password = $newUserData['password'];
// 	$vals = array($username, $password, $lastname, $firstname, $email);
// 	$stmnt->execute($vals);
// }

function db_addNewUser2($dbh, $newUserData){
	$stmnt = $dbh->prepare('INSERT INTO benutzer (username, password, lastname, firstname, email) VALUES (:username, :password, :lastname, :firstname, :email)');

	$firstname = $newUserData['firstname'];
	$lastname = $newUserData['lastname'];
	$email = $newUserData['email'];
	$username = $newUserData['username'];
	$password = $newUserData['password'];

	$stmnt->bindparam(':username', $username);
	$stmnt->bindparam(':password', $password);
	$stmnt->bindparam(':lastname', $lastname);
	$stmnt->bindparam(':firstname', $firstname);
	$stmnt->bindparam(':email', $email);

	$stmnt->execute();
}

// function db_addNewUser3($dbh, $newUserData){
// 	$stmnt = $dbh->prepare('INSERT INTO benutzer (username, password, lastname, firstname, email) VALUES (?,?,?,?,?)');

// 	$firstname = $newUserData['firstname'];
// 	$lastname = $newUserData['lastname'];
// 	$email = $newUserData['email'];
// 	$username = $newUserData['username'];
// 	$password = $newUserData['password'];

// 	$stmnt->bindparam(1, $username);
// 	$stmnt->bindparam(2, $password);
// 	$stmnt->bindparam(3, $lastname);
// 	$stmnt->bindparam(4, $firstname);
// 	$stmnt->bindparam(5, $email);

// 	$stmnt->execute();
// }







