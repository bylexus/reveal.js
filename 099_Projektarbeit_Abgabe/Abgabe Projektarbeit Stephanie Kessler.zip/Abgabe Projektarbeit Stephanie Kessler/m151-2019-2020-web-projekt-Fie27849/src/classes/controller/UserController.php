<?php
namespace M151\controller;

use M151\model\UserModel;
use M151\view\UserView;
// Datei für DB Zugriff einbinden
require_once("inc/db_config.inc.php");


class UserController {

	function getUser(){
		$UserView = new UserView;
		$UserView->showUser();
		$formData = $UserView->showLoginForm();
		$this->checkUser($formData);
	}

	function checkUser($formData){
		$dbh = db_connect();
		$user = db_getUserByLogin($dbh, $formData['username']);
		$userFormUsername = $formData['username'];
		$userFormPassword = $formData['password'];
		$userSavedPassword = $user['password'];

		echo "<br /><br />";
		echo "<br />Form entered Password: " . $userFormPassword;
		echo "<br />Saved in DB Password: " . $userSavedPassword;

		if($userFormPassword){			
			if($userFormPassword == $userSavedPassword){
				echo "<br />Passwort stimmt.";
			}
		}
	}

	function register(){
		$UserView = new UserView;
		$UserView->showSignup();
		$newUserData = $UserView->showNewUserForm();
		$dbh = db_connect();
		$existingUserName = $newUserData['username'];
		$existingUser = db_getUserByLogin($dbh, $existingUserName);
		if($existingUser['username'] && $existingUser['password']){
			echo "FEHLER: Benutzer wurde bereits erfasst.";
		}else{
			db_addNewUser2($dbh, $newUserData);
		}
	}

}