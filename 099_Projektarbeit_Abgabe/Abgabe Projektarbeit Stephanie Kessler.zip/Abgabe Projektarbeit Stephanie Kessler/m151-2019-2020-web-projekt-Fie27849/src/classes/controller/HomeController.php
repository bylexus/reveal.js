<?php
namespace M151\controller;

use M151\model\HomeModel;
use M151\view\HomeView;
// Datei fürDB Zugriff einbinden
require_once("inc/db_config.inc.php");

class HomeController {

	public function getHome(){
		$showHome = new HomeView;
		$showHome->showHome();


	}
}