<?php

namespace M151\model;

class UserModel{
	
}