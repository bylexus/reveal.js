<?php

namespace M151\model;

class WeatherModel{

	public $timestamp;
	public $location;
	public $description;
	public $temp;
	public $pressure;
	public $humidity;
	public $icon;

	public function weatherRawToNice($weatherRaw){

		$this->timestamp = time();
		$this->location = $weatherRaw->name;
		$this->description = $weatherRaw->weather[0]->description;
		$this->temp = $weatherRaw->main->temp;
		$this->pressure = $weatherRaw->main->pressure;
		$this->humidity = $weatherRaw->main->humidity;
		$this->icon = $weatherRaw->weather[0]->icon;

	}

	
}