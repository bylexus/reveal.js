<?php
namespace M151\view;

class UserView{

	function showUser(){
		echo "<h1>Benutzer</h1>";
	}

	function showSignup(){
		echo "<h1>Registrieren</h1>";
	}

	function showLoginForm(){
		$loginForm = '<form method="POST">
			<label for="username">Username:</label><br>
			<input type="text" name="username">
			<br>
			<label for="password">Password:</label><br>
			<input type="text" name="password">
			<br><br>
			<input type="submit" value="Submit">
			</form>';
		echo $loginForm;

		$formData;
		if(isset($_POST['username'])){
			$formData['username'] = $_POST['username'];
		}else{
			$formData['username'] = NULL;
		}
		if(isset($_POST['password'])){
			$formData['password'] = $_POST['password'];
		}else{
			$formData['password'] = NULL;
		}
		return $formData;
	}

	function showNewUserForm(){
		$newUserForm = '<form method="POST">
			<label for="firstname">Vorname:</label><br>
			<input type="text" name="firstname">
			<br>
			<label for="lastname">Nachname:</label><br>
			<input type="text" name="lastname">
			<br>
			<label for="email">E-Mail:</label><br>
			<input type="text" name="email">
			<br>
			<label for="username">Username:</label><br>
			<input type="text" name="username">
			<br>
			<label for="password">Password:</label><br>
			<input type="text" name="password">
			<br><br>
			<input type="submit" value="Submit">
			</form>';
		echo $newUserForm;

		$newUserData;
		if(isset($_POST['firstname'])){
			$newUserData['firstname'] = $_POST['firstname'];
		}else{
			$newUserData['firstname'] = NULL;
		}
		if(isset($_POST['lastname'])){
			$newUserData['lastname'] = $_POST['lastname'];
		}else{
			$newUserData['lastname'] = NULL;
		}
		if(isset($_POST['email'])){
			$newUserData['email'] = $_POST['email'];
		}else{
			$newUserData['email'] = NULL;
		}
		if(isset($_POST['username'])){
			$newUserData['username'] = $_POST['username'];
		}else{
			$newUserData['username'] = NULL;
		}
		if(isset($_POST['password'])){
			$newUserData['password'] = $_POST['password'];
		}else{
			$newUserData['password'] = NULL;
		}
		return $newUserData;

	}

}
