<?php
namespace M151\view;

class WeatherView{

	function showWeather($weatherNice){

		echo '<!DOCTYPE html><html><head><title>Wetter</title></head><body><h1>Wetter vom ' . date('d/m/Y H:i:s', $weatherNice->timestamp) . '</h1><p><img src="' . $weatherNice->icon . '" /> Es herrscht ' . $weatherNice->description . ', bei ' . $weatherNice->temp . '°C, ' . $weatherNice->humidity . '% Luftfeuchtigkeit und ' . $weatherNice->pressure . 'hPa Luftdruck.</p></body></html>';
	}


}
