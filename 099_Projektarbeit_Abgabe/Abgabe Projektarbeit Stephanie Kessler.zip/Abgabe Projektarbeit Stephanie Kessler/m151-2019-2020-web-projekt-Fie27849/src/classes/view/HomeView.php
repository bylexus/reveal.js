<?php
namespace M151\view;

class HomeView{

	public function showHome(){
		echo "<h1>Startseite</h1>";
		
	}
	
}