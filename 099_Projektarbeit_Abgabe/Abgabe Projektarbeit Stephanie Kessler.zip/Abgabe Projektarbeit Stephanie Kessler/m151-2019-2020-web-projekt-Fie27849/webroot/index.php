<?php

# lade composer autoloader:
require_once __DIR__ . '/../vendor/autoload.php';

// Menu
echo "<div class=\"menu\"><ul><li><a href=\"/webroot/home\">Startseite</a></li><li><a href=\"/webroot/user\">Anmelden</a></li><li><a href=\"/webroot/user/register\">Registrieren</a></li><li><a href=\"/webroot/weather\">Wetter</a></li></ul></div>    ";


// gibt die mitgegebenen Parameter aus, falls welche vorhanden sind
// if($_REQUEST){
// 	echo "requested params:\n";
// 	var_dump($_REQUEST);
// 	if($_REQUEST['name']){
// 		echo "Parameter können aus der $ REQUEST Variable(Array) gelesen werden:\n";
// 		echo "Hallo {$_REQUEST['name']}";
// 	}
// }

// Fehlermeldungen deaktivieren
error_reporting(0);
// Path Variable setzen und in Array aufteilen
$serverPath = $_SERVER['PATH_INFO'];
$splitPathBy = "/";
$actionPath = explode($splitPathBy, $serverPath);

// Pfad zur Methode zusammensetzen
if(count($actionPath) == 3) {
	$controller = strtolower($actionPath[1]) . 'Controller';
	$controller[0] = strtoupper($controller[0]);
	$controller = 'M151\controller\\' . $controller;
	$action = $actionPath[2];
	$ctrl = new $controller();
	$ctrl->$action();
	return;
}

if(count($actionPath) == 2){
	$controller = strtolower($actionPath[1]) . 'Controller';
	$controller[0] = strtoupper($controller[0]);
	$controller = 'M151\controller\\' . $controller;

	if($controller == "M151\controller\HomeController"){
		//echo "\nController is Home";
		$ctrl = new $controller();
		$ctrl->getHome();
		return;
	}elseif($controller == "M151\controller\WeatherController"){
		//echo "\nController is Weather";
		$ctrl = new $controller();
		$ctrl->getWeather();
		return;
	}elseif($controller == "M151\controller\UserController"){
		//echo "\nController is User";
		$ctrl = new $controller();
		$ctrl->getUser();
		return;
	}else{
		$controller = "M151\controller\HomeController";
		$ctrl = new $controller();
		$ctrl->getHome();
		return;
	}
}

if(count($actionPath) == 1){
	$controller = "M151\controller\HomeController";
	$ctrl = new $controller();
	$ctrl->getHome();
	return;
}













