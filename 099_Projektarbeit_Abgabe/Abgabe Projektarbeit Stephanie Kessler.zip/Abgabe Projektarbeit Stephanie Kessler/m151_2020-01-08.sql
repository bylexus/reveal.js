# ************************************************************
# Sequel Pro SQL dump
# Version 5438
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 8.0.15)
# Database: m151
# Generation Time: 2020-01-08 21:17:27 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table benutzer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `benutzer`;

CREATE TABLE `benutzer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `password` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `lastname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `firstname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `user_status` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `user_role` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `benutzer` WRITE;
/*!40000 ALTER TABLE `benutzer` DISABLE KEYS */;

INSERT INTO `benutzer` (`id`, `username`, `password`, `lastname`, `firstname`, `email`, `last_login`, `session_id`, `user_status`, `user_role`)
VALUES
	(1,'alex','geheim','Schenkel','Alex','alex@alexi.ch',NULL,NULL,'active','user'),
	(2,'frodo','ring','Beutlin','Frodo','frodo@auenland.net',NULL,NULL,'active','user'),
	(3,'bilbo','schatz','Beutlin','Bilbo','bilbo@auenland.net',NULL,NULL,'active','user'),
	(4,'thorin','gold','Eichenschild','Thorin','thorin@moria.net',NULL,NULL,'active','user'),
	(5,'alexweber','123456','weber','alexandra','alex@weber.ch',NULL,NULL,'active','user'),
	(15,'selinathomas','9876543','thomas','selina','selina@thomas.ch',NULL,NULL,'inactive','admin'),
	(18,'alexkessler','324234','kessler','alex','alex@kessler.ch',NULL,NULL,'inactive','user'),
	(19,'lydiajakob','324234','jakob','lydia','lydia@jakob.ch',NULL,NULL,'inactive','user'),
	(20,'dariojakob','87654','jakob','dario','dario@jakob.ch',NULL,NULL,'active','admin'),
	(21,'janisweber','123456','weber','janis','janis@weber.ch',NULL,NULL,'active','admin');

/*!40000 ALTER TABLE `benutzer` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table note
# ------------------------------------------------------------

DROP TABLE IF EXISTS `note`;

CREATE TABLE `note` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(20) DEFAULT NULL,
  `text` varchar(250) DEFAULT NULL,
  `title` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
