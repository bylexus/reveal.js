<?php

namespace M151\Database;

class DB {
//-------------------------------------------------------------------------------------------------
    private static $INSTANCE = NULL;
    private $dbConnection = NULL;
//-------------------------------------------------------------------------------------------------
    private function __construct() 
    {
        include('db.confing.php');
        $this->dbConnection = new \PDO($dsn, $username, $password, $options);
    }
//-------------------------------------------------------------------------------------------------
    public static function getInstance()
    {
        if (static::$INSTANCE == null) {
            static::$INSTANCE = new DB();
        }
        return static::$INSTANCE;
    }
//-------------------------------------------------------------------------------------------------
    public function getConn()
    {
        return $this->dbConnection;    
    }
    

} 



?>