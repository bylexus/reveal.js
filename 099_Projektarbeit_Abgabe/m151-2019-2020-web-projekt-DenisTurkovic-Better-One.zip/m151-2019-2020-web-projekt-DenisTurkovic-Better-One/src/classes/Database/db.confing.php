<?php
/*
    Eigentlich dürfte das nicht ins Repo
*/
$dsn = 'mysql:host=127.0.0.1;port=3306;dbname=notfacebook';
$username = 'root';
$password = '';
$options = array(
    // UTF8 
    \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
);

?>