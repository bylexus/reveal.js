<?php

namespace M151;

class Router 
{
//-------------------------------------------------------------------------------------------------    
    private static $INSTANCE = null;
    private $routeList = [];
//-------------------------------------------------------------------------------------------------
    private function __construct() 
    {
    }
//-------------------------------------------------------------------------------------------------
    public static function getInstance()
    {
        if (static::$INSTANCE == null) {
            static::$INSTANCE = new Router();
        }
        return static::$INSTANCE;
    }
//-------------------------------------------------------------------------------------------------
    public function addRoute($route, $httpMethod, $controllClass, $actionFunction)
    {
        $this->routeList[] = [ // $array[] = [] equals array.push() or array.append()
            'route' => $route,
            'method' => $httpMethod,
            'controller' => $controllClass,
            'action' => $actionFunction
        ];
    }
//-------------------------------------------------------------------------------------------------
    public function findRouteItem($request)
    {
        $route = $request->urlRoute;
        $method = $request->method;
        
        foreach($this->routeList as $routeItem) {
            if ($routeItem['route'] === $route  && 
                    ($routeItem['method'] === null || 
                        $method === $routeItem['method']))
                return $routeItem;
        }
        return null;
    }
//-------------------------------------------------------------------------------------------------
    public function getRouteController($routeInfo)
    {
        if ($routeInfo == null)
            return null;

        $controllClass = $routeInfo['controller'];
        $c = new $controllClass();
        return $c;

    }
}




?>