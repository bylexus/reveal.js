<?php

namespace M151;
use M151\Model\FileModel;

//-------------------------------------------------------------------------------------------------
class FileSystem 
{
//-------------------------------------------------------------------------------------------------
    public const User = "user/";
    public const Post = "posts/";
    private $root;
    private $mode;
//-------------------------------------------------------------------------------------------------
    public function __construct($folder)
    {
        $this->root = $_SERVER['DOCUMENT_ROOT'] ."/files/";
        switch ($folder) {
            case FileSystem::User:
                $this->root .= FileSystem::User;
                $this->mode = FileSystem::User;
            break;
            case FileSystem::Post:
                $this->root .= FileSystem::Post;
                $this->mode = FileSystem::Post;
            break;
            default:
                break;
        }
    }
//-------------------------------------------------------------------------------------------------
    public function getFile($id)
    {
        $model = new FileModel();
        $row = "";
        switch ($this->mode) {
            case FileSystem::User:
                $row = $model->getUserFile($id);
                break;
            case FileSystem::Post:
                $row = $model->getPostFile($id);
                break;
            default:
                break;
        }
        $fullpath = $this->root . $row["localpath"];
        if(!(file_exists($fullpath) && filesize($fullpath) == $row["size"])) {
            return null;
        }

        // TODO CHECK IF FILE EXISTS
        $file = array(
            "name" => $row['origfilename'], // $row["name"]
            "path" =>  $fullpath,
            "mimetype" => mime_content_type($fullpath)
        );

        return $file;
    }
//-------------------------------------------------------------------------------------------------
    public function saveFile($file, $id)
    {
        $info = pathinfo($file['name']);
        $ext = $info['extension']; // get the extension of the file
        $newname = $id.".".$ext; 

        $target = $this->root. $newname;
        move_uploaded_file($file['tmp_name'], $target);
        $model = new FileModel();
        $data = array(
            'origfilename' => $file['name'],
            'localpath' => $newname,
            'size' => $file['size'],
            'fkid' => $id
        );
        $model->insertFile($data);
    }
//-------------------------------------------------------------------------------------------------
    public function putFile($file, $id) 
    {
        $info = pathinfo($file['name']);
        $ext = $info['extension']; // get the extension of the file
        $newname = $id.".".$ext; 

        $target = $this->root. $newname;
        if (file_exists($target))
            unlink($target);

        move_uploaded_file($file['tmp_name'], $target);
        $model = new FileModel();
        $data = array(
            'origfilename' => $file['name'],
            'localpath' => $newname,
            'size' => $file['size'],
            'fkid' => $id
        );
        
        $model->updateFile($data);
    }
}

?>