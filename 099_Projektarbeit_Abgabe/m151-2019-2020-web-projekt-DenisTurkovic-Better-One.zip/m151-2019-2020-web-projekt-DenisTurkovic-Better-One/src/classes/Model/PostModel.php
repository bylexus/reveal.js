<?php

namespace M151\Model;
use M151\Database\DB;

class PostModel extends BaseModel 
{
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct(DB::getInstance()->getConn());
    }
//-------------------------------------------------------------------------------------------------
    public function getTable()
    {
        return "posts";
    }
//-------------------------------------------------------------------------------------------------
    public function getColumns() 
    {
        return array();
    }
//-------------------------------------------------------------------------------------------------
    public function appendPost($data)
    {
        $tbl = $this->getTable();
        // TODO Check parent is Valid?
        $query = "
        INSERT INTO $tbl 
        (creator, data, parent) VALUES (:creator, :data, :parent);
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $this->dbConn->lastInsertId();
    }
//-------------------------------------------------------------------------------------------------
    public function insertPost($data) 
    {
        // TODO Check data?
        $tbl = $this->getTable();
        $query = "
        INSERT INTO $tbl 
        (creator, data) VALUES (:creator, :data);
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $this->dbConn->lastInsertId();
    }
//-------------------------------------------------------------------------------------------------
    public function getPosts($id, $limit) 
    {
        // TODO get Posts from Friend of userid
        $tlb = $this->getTable();
        $query = "
        SELECT T.* FROM (
        Select p.id, u.surname, p.created, p.data From posts as p
        INNER JOIN user as u on p.creator = u.id
        JOIN friends as f on f.usersid = p.creator
        WHERE (f.usersid = :userid OR f.friendsid = :userid AND f.accepted = 1 OR p.creator = :userid ) AND p.parent IS NULL
        UNION
        Select p.id, u.surname, p.created, p.data From posts as p
        INNER JOIN user as u on p.creator = u.id
        JOIN friends as f on f.friendsid = p.creator
        WHERE (f.usersid = :userid OR f.friendsid = :userid AND f.accepted = 1 OR p.creator = :userid ) AND p.parent IS NULL
        ) AS T
        ORDER BY t.created DESC
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute(array("userid" => $id));
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $allPosts = array();

        foreach ($rows as $row) {
            $allPosts[] = array(
                "id" => $row["id"],
                "creator" => $row["surname"],
                "created" => $row["created"],
                "text" => $row["data"],
                "imgUrl" => "/webroot/file/post?id=". $row['id'],
                "comment" => array()
            );
        }

        $query = "
        Select p.id, u.surname, p.data, p.created, p.parent From posts as p
        INNER JOIN user as u on p.creator = u.id
        WHERE p.parent IS NOT NULL;
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute(array("userid" => $id));
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            foreach ($allPosts as &$post) {
                if ($row["parent"] == $post["id"]) {
                    array_push($post["comment"],array(
                        "id" => $row["id"],
                        "creator" => $row["surname"],
                        "created" => $row["created"],
                        "text" => $row["data"],
                        "imgUrl" => "/webroot/file/post?id=". $row['id']
                    ));
                }
            }
        }

        return $allPosts;
    }
}
?>