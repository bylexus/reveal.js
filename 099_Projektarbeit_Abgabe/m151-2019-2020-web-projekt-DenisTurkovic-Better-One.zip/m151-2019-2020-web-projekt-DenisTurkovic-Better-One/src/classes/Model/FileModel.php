<?php

namespace M151\Model;
use M151\Database\DB;

class FileModel extends BaseModel 
{
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct(DB::getInstance()->getConn());
    }
//-------------------------------------------------------------------------------------------------
    public function getTable()
    {
        return "filecontent";
    }
//-------------------------------------------------------------------------------------------------
    public function getColumns() 
    {
        return array(
            'id' => 'int',
            'origfilename' => 'string',
            'localpath' => 'string',
            'size' => 'int',
            'fkid' => 'int'
        );
    }
//-------------------------------------------------------------------------------------------------
    public function getUserFile($id)
    {
        $id = $this->cleanValue($id);
        $tbl = $this->getTable();
        $cols = $this->getColumns();

        //TODO SQL INJECTION
        $query = "
        SELECT localpath,origfilename,size from $tbl
        INNER JOIN user on filecontent.fkid = user.id
        WHERE user.id = :userid
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute(array('userid' => $id));
        $row = $stmt->fetchall(\PDO::FETCH_ASSOC);
        return $row[0];
    }
//-------------------------------------------------------------------------------------------------
    public function getPostFile($id)
    {
        $id = $this->cleanValue($id);
        $tbl = $this->getTable();
        $cols = $this->getColumns();

        //TODO SQL INJECTION
        $query = "
        SELECT localpath,origfilename,size from $tbl
        INNER JOIN posts on $tbl.fkid = posts.id
        WHERE posts.id = :postid
        ";
        
        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute(array('postid' => $id));
        $row = $stmt->fetchall(\PDO::FETCH_ASSOC);
        return $row[0];
    }
//-------------------------------------------------------------------------------------------------
    public function insertFile($data)
    {
        // TODO CLEAN VALUE
        // TODO CHECK DATA FORMAT
        $tbl = $this->getTable();

        $query = "
        INSERT INTO $tbl (origfilename, localpath, size, fkid)
        VALUES (:origfilename, :localpath, :size, :fkid);
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);

    }
//-------------------------------------------------------------------------------------------------
    public function updateFile($data) 
    {
        // TODO CLEAN VALUE
        // TODO CHECK DATA FORMAT
        $tbl = $this->getTable();
        $query = "
        UPDATE $tbl
        SET
        origfilename = :origfilename,
        localpath = :localpath,
        size = :size,
        date = NOW()
        WHERE fkid = :fkid
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $success;
    }
}
?>