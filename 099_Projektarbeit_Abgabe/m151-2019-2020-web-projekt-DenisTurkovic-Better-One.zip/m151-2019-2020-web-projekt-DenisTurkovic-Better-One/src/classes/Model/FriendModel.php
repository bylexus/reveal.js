<?php

namespace M151\Model;
use M151\Database\DB;

// Table accepted
// 0 = sent
// 1 = accepted
// deny = remove row
// TODO FIXME: Freundschaft überschreiben

class FriendModel extends BaseModel 
{
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct(DB::getInstance()->getConn());
    }
//-------------------------------------------------------------------------------------------------
    public function getTable()
    {
        // TODO Find better solution for multiple tables
        return "friends";
    }
//-------------------------------------------------------------------------------------------------
    public function getColumns() 
    {
        return array(
            'id' => 'int',
            'userid' => 'id',
            'friendsid' => 'id',
            'accepted' => 'bool'
        );
    }
//-------------------------------------------------------------------------------------------------
    public function getAllUsers($data)
    {
        // TODO Check data
        $query = "
        Select id, surname, firstname from user
        WHERE id != :userid
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $users = array();

        // Format
        foreach($rows as $row) {
            $users[] = array(
                "id" => $row["id"],
                "surname" => $row["surname"],
                "firstname" => $row["firstname"]
            );
        }

        $query = "
        Select * from friends
        Where usersid = :userid or friendsid = :userid
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $friendRequests = array();

        foreach($users as &$user) {
            foreach($rows as $row) {
                if ($user["id"] == $row["usersid"] || $user["id"] == $row["friendsid"])
                    if ($row["accepted"] > 0) {
                        $user["isFriend"] = true;
                    } else if ($row["accepted"] < 1) {
                        $friendRequests[] = array("id" => $user["id"], "surname" => $user["surname"], "firstname" => $user["firstname"]);
                    }
            }
        }
        $users["friendRequests"] = $friendRequests;
        return $users;
    }
//-------------------------------------------------------------------------------------------------
    public function sendFriendRequest($data)
    {
        $tbl = $this->getTable();
        $query = "
        INSERT INTO $tbl 
        (usersid, friendsid) VALUES (:userid, :friendid);
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $success;
    }
//-------------------------------------------------------------------------------------------------
    public function acceptFriendRequest($data)
    {
        $tbl = $this->getTable();
        $query = "
        UPDATE $tbl
        SET accepted = 1
        WHERE (usersid = :friendid and friendsid = :userid) OR
        (usersid = :userid and friendsid = :friendid) 
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $success;
    }
//-------------------------------------------------------------------------------------------------
    public function denyFriendRequest($data)
    {
        $tbl = $this->getTable();
        $query = "
        DELETE FROM $tbl
        WHERE (usersid = :friendid and friendsid = :userid) OR
        (usersid = :userid and friendsid = :friendid) 
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $success;
    }
}
?>