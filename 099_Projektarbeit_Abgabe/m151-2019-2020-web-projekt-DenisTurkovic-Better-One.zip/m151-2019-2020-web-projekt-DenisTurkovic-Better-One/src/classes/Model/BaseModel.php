<?php

namespace M151\Model;

abstract class BaseModel {
//-------------------------------------------------------------------------------------------------
    protected $dbConn = NULL;
//-------------------------------------------------------------------------------------------------
    public function __construct($dbh) 
    {
        //TODO gleich Singleton verwenden
        if ($dbh == NULL) {
            echo "WARNING CONNECTION NULL $this";
            return;
        }
        $this->dbConn = $dbh;
    }
//-------------------------------------------------------------------------------------------------
    abstract public function getTable();
    abstract public function getColumns();
//-------------------------------------------------------------------------------------------------
    public function cleanValue($value) 
    {
        //TODO sql injection fix
        return $value;
    } 
//-------------------------------------------------------------------------------------------------
    public function get($id) 
    {
        $res = $this->selectQuery($this->cleanValue($id));
        return $res ? $res[0] : NULL; 
    }
//-------------------------------------------------------------------------------------------------
    public function update($id, $data) 
    {

    }
//-------------------------------------------------------------------------------------------------
    public function updateOne($id, $key, $value) 
    {

    }
//-------------------------------------------------------------------------------------------------
    public function delete($id) 
    {

    }
//-------------------------------------------------------------------------------------------------
    public function selectQuery($filter, $orderBy = NULL) 
    {
        $filter = $this->cleanValue($filter);
        $orderBy = $this->cleanValue($orderBy);

        $tbl = $this->getTable();
        $cols = $this->getColumns();
        $selectString = $this->buildColumnString($cols);

        $orderBy = ($orderBy == NULL) ? '' : "ORDER BY {$orderBy}";
        $query = "SELECT {$selectString} FROM {$tbl} WHERE {$filter} {$orderBy};";
        var_dump($query);
        return $this->dbConn->query($query)->fetchAll(\PDO::FETCH_ASSOC);
    }
//-------------------------------------------------------------------------------------------------
    public function buildColumnString($cols) 
    {
        $colKeys = array_keys($cols); // get All Keys
        return join(',', $colKeys); // builds String
    }
//-------------------------------------------------------------------------------------------------
    
}

?>