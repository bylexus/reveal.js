<?php

namespace M151\Model;
use M151\Database\DB;

class UserModel extends BaseModel 
{
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct(DB::getInstance()->getConn());
    }
//-------------------------------------------------------------------------------------------------
    public function getTable()
    {
        return "user";
    }
//-------------------------------------------------------------------------------------------------
    public function getColumns() 
    {
        return array(
            'id' => 'int',
            'email' => 'string',
            'password' => 'string',
            'surname' => 'string',
            'firstname' => 'string'
        );
    }
//-------------------------------------------------------------------------------------------------
    public function getUser($data)
    {
        $hasPassword = false;
        $filter = "";
        $queryData =array();
        // TODO Bessere lösung?
        if (!(is_null(@$data["id"]))) {
            $filter = "id = :id;";
            $queryData["id"] = $this->cleanValue($data["id"]);

        } elseif (!(is_null(@$data["email"]))) {
            $filter = "email = :email;";
            $queryData["email"] = $this->cleanValue($data["email"]);
            $hasPassword = true;
        }

        $tbl = $this->getTable();
        $cols = $this->getColumns();
        $query = "SELECT id, email, password, surname, firstname FROM {$tbl} WHERE " . $filter;

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($queryData);

        $row = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        if ($hasPassword) {
            if (password_verify($data["password"], $row[0]["password"]))
                return $row[0];
            else
                return NULL;
        } else
            return $row[0];
    }
//-------------------------------------------------------------------------------------------------
    public function registerUser($data)
    {
        // TODO CLEAN VALUE
        // TODO CHECK DATA FORMAT
        $tbl = $this->getTable();

        //CHECK IF NOT SOMEONE HAS SAME USERS INFOS
        $query = "
        INSERT INTO $tbl (email, password, surname, firstname)
        VALUES (:email, :password, :surname, :firstname)
        ";
        
        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $this->dbConn->lastInsertId();
    }
//-------------------------------------------------------------------------------------------------
    public function updateUser($data)
    {
        $user = $this->getUser(array("id" => $data["userid"]));

        if (is_null($user))
            return false;
        if (!(password_verify($data["password"], $user["password"])))
            return false;
        if (array_key_exists("password", $data))
            unset($data["password"]);

        $tbl = $this->getTable();
        // TODO Check data ?
        $query = "
        UPDATE $tbl
        SET
        firstname = :firstname,
        surname = :surname
        WHERE id = :userid;
        ";

        $stmt = $this->dbConn->prepare($query);
        $success = $stmt->execute($data);
        return $success;
    }

}
?>