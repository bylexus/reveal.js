<?php

namespace M151;

use M151\Router;
use M151\Request;

class App 
{
//-------------------------------------------------------------------------------------------------
    private static $INSTANCE = NULL;

    public $request = null;
    public $controller = null;
    public $routeItem = null;
    public $router = null;
//-------------------------------------------------------------------------------------------------
    private function __construct() 
    {
        $this->router =  Router::getInstance();
        $this->request = new Request($_REQUEST, $_SERVER, $_FILES);
    }
//-------------------------------------------------------------------------------------------------
    public static function getInstance() 
    {
        if (static::$INSTANCE == null) {
            static::$INSTANCE = new App();
        }
        return static::$INSTANCE;
    }
//-------------------------------------------------------------------------------------------------
    public function exec() 
    {
        $this->routeItem = $this->router->findRouteItem($this->request);
        $this->controller = $this->router->getRouteController($this->routeItem);
        $actionFn = $this->routeItem['action'];
        if(is_null($this->controller) || is_null($this->routeItem) ||
            empty($actionFn)
            
        ){
            return false;
        }
        $this->controller->$actionFn($this->request);
        return true;

    }
//-------------------------------------------------------------------------------------------------
    protected function str_lreplace($search, $replace, $subject)
    {
        $pos = strrpos($subject, $search);
        if ($pos !== false) {
            $subject = substr_replace($subject, $replace, $pos, strlen($search));
        }
        return $subject;
    }
//-------------------------------------------------------------------------------------------------
    public function routeUrl($url) 
    {
        // FULL URL
        $requestUri = preg_replace('/\?.*/', '', $_SERVER['REQUEST_URI']);
        $routePath = $_SERVER['PATH_INFO'];
        return $this->str_lreplace($routePath, '', $requestUri) . $url;
    }
}


?>