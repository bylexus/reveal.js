<?php

namespace M151;

class Request 
{
//-------------------------------------------------------------------------------------------------
    private $origRequest;
    private $serverInfo;
    private $files;

    public $urlRoute = '/';
    public $method = 'GET';
//-------------------------------------------------------------------------------------------------
    public function __construct($request, $serverInfo, $files)
    {
        $this->origRequest = $request;
        $this->serverInfo = $serverInfo;
        $this->files = $files;
        
        $this->urlRoute = isset($this->serverInfo['PATH_INFO']) ? $this->serverInfo['PATH_INFO'] : '/';
        $this->method = isset($this->serverInfo['REQUEST_METHOD']) ? $this->serverInfo['REQUEST_METHOD'] : 'GET';
    }
//-------------------------------------------------------------------------------------------------
    public function getParams() 
    {
        if (is_array($this->origRequest)) {
            return $this->origRequest;
        } else {
            return [];
        }
    }
//-------------------------------------------------------------------------------------------------
    public function getParam($name)
    {
        if (!empty($this->origRequest[$name])) {
            return $this->origRequest[$name];
        } else {
            if (!(empty($this->files[$name]))) {
                if ($this->files[$name]['size'] > 0)
                return $this->files[$name];
            }
            else
                return null;
        }
    }

}



?>