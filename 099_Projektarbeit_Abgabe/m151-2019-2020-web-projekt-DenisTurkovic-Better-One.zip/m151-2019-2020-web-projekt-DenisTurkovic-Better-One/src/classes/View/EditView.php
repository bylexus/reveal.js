<?php

namespace M151\View;

use M151\Request;
use M151\App;

class EditView extends BaseView {
//-------------------------------------------------------------------------------------------------
    
//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
        $this->viewData["headerTitle"] = "Edit";
    }
//-------------------------------------------------------------------------------------------------
    public function display($data)
    {
        if(!empty($data))
            $this->viewData += $data;

        $this->viewData["url"] = App::getInstance()->routeUrl("/edit");
        $this->smarty->assign($this->viewData);
        $this->smarty->display('editUser.tpl');
    }
}

?>