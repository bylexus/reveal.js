<?php

namespace M151\View;

use M151\Request;
use M151\App;

class LoginView extends BaseView {
//-------------------------------------------------------------------------------------------------
    
//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
        $this->viewData["headerTitle"] = "Login";
    }
//-------------------------------------------------------------------------------------------------
    public function display($data)
    {
        if(!empty($data))
            $this->viewData += $data;

        $this->viewData["url"] = App::getInstance()->routeUrl("/login");
        $this->smarty->assign($this->viewData);
        $this->smarty->display('login.tpl');
    }
}

?>