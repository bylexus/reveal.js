<?php

namespace M151\View;

use M151\Request;
use M151\App;

class FriendView extends BaseView {
//-------------------------------------------------------------------------------------------------
    
//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
        $this->viewData["headerTitle"] = "Friends";
    }
//-------------------------------------------------------------------------------------------------
    public function display($data)
    {
        if(!empty($data))
            $this->viewData += $data;

        $this->viewData["sendFriendRequestUrl"] = "/webroot/friend/sent";
        $this->viewData["denyFriendRequestUrl"] = "/webroot/friend/deny";
        $this->viewData["acceptFriendRequestUrl"] = "/webroot/friend/accept";
        
        $this->smarty->assign($this->viewData);
        $this->smarty->display('friends.tpl');
    }
//-------------------------------------------------------------------------------------------------
    public function injectData($key, $data)
    {
        if(!empty($data)) {
            $this->viewData[$key] = $data;
        }
    }
}

?>