<?php
namespace M151\View;
use M151\MySmarty;
use M151\Request;

abstract class BaseView {
//-------------------------------------------------------------------------------------------------
    protected $smarty;
    protected $viewData;
//-------------------------------------------------------------------------------------------------
    abstract public function display($data);
//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        $this->smarty = MySmarty::getInstance()->smarty; 
        
        $data = 
        array(
            array(
                "link" => "/webroot/login",
                "name" => "Login"
            
            ),
            array(
                "link" => "/webroot/register",
                "name" => "Register"
            ),
            array(
                "link" => "/webroot/home",
                "name" => "Home"
            ),
            array(
                "link" => "/webroot/edit",
                "name" => "Edit Userprofile" 
            ),
            array(
                "link" => "/webroot/friend",
                "name" => "Search Friends"
            ),
            array(
                "link" => "/webroot/logout",
                "name" => "Logout"
            )
        );

        $this->viewData["navigation"] = $data;
    
    }
//-------------------------------------------------------------------------------------------------
}


?>