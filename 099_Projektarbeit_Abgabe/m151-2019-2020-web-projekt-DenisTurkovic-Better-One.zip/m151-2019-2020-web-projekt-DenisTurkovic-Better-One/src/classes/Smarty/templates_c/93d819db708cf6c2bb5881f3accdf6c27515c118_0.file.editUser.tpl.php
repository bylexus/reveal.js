<?php
/* Smarty version 3.1.33, created on 2020-01-08 09:43:33
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\editUser.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5e159635e64249_73567560',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '93d819db708cf6c2bb5881f3accdf6c27515c118' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\editUser.tpl',
      1 => 1578473000,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e159635e64249_73567560 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
" enctype="multipart/form-data"> 
        
        <label> Firstname </label>
        <input type="text" name="firstname" value="<?php echo $_smarty_tpl->tpl_vars['firstname']->value;?>
" required> <br />
        <label> Surname </label>
        <input type="text" name="surname" value="<?php echo $_smarty_tpl->tpl_vars['surname']->value;?>
" required> <br />
        <label> Picture </label>
        <?php if (isset($_smarty_tpl->tpl_vars['imgUrl']->value)) {?>
            <img src="<?php echo $_smarty_tpl->tpl_vars['imgUrl']->value;?>
" width="100px" height="100px">
        <?php }?>
        <input type="file" name="picture"> <br />
        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
" > <br />
        <p>Please enter your password to confirm the changes</p>
        <label> Password </label>
        <input type="password" name="password" required> <br />
        <label> Re-enter Password </label>
        <input type="password" name="secondpassword" required> <br />
        <input type="submit"> 
        
        <?php if (isset($_smarty_tpl->tpl_vars['errorMsg']->value)) {?>
            <p><?php echo $_smarty_tpl->tpl_vars['errorMsg']->value;?>
</p>
        <?php }?>
    </form>

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
