<?php
/* Smarty version 3.1.33, created on 2020-01-07 19:58:00
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\friends.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5e14d4b8a623f2_01659808',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14e2822492158805fada3259987491596a4d15ba' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\friends.tpl',
      1 => 1578423477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e14d4b8a623f2_01659808 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<h2>Friend Requests</h2>
<?php if (!empty($_smarty_tpl->tpl_vars['friendRequests']->value)) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['friendRequests']->value, 'friendReqeust');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['friendReqeust']->value) {
?>
    <p><?php echo $_smarty_tpl->tpl_vars['friendReqeust']->value["surname"];?>
, <?php echo $_smarty_tpl->tpl_vars['friendReqeust']->value["firstname"];?>
 wants to be Friend with you</p>
    <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['acceptFriendRequestUrl']->value;?>
">
        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['friendReqeust']->value["id"];?>
">
        <input type="submit" value="Accept"> 
    </form>
    <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['denyFriendRequestUrl']->value;?>
">
        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['friendReqeust']->value["id"];?>
">
        <input type="submit" value="Deny"> 
    </form>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
} else { ?>
<p>NO Requests available</p>
<?php }?>
<h2>Find Friends</h2>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
?>
    <p><?php echo $_smarty_tpl->tpl_vars['user']->value["surname"];?>
 , <?php echo $_smarty_tpl->tpl_vars['user']->value["firstname"];?>
</p>
    <?php if (array_key_exists("isFriend",$_smarty_tpl->tpl_vars['user']->value)) {?>
    <small> is already a Friend</small>
    <?php } else { ?>
    <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['sendFriendRequestUrl']->value;?>
">
        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['user']->value["id"];?>
">
        <input type="submit" value="Send Friend Request"> 
    </form>
    <?php }
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
