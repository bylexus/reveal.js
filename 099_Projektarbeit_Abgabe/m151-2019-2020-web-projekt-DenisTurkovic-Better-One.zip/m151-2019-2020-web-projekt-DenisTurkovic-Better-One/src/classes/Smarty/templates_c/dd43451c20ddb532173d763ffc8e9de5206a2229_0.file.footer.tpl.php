<?php
/* Smarty version 3.1.33, created on 2019-12-08 12:08:05
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5decd9955147c5_28947649',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dd43451c20ddb532173d763ffc8e9de5206a2229' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\footer.tpl',
      1 => 1575802586,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5decd9955147c5_28947649 (Smarty_Internal_Template $_smarty_tpl) {
?><footer>

</footer>
</body>
</html><?php }
}
