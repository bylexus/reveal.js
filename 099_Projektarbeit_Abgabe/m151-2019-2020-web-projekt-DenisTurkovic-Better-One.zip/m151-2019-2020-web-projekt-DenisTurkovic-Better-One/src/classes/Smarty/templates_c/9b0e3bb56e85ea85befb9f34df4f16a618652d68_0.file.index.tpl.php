<?php
/* Smarty version 3.1.33, created on 2019-10-01 12:51:26
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d932faec8baa1_69899293',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9b0e3bb56e85ea85befb9f34df4f16a618652d68' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\index.tpl',
      1 => 1569926366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d932faec8baa1_69899293 (Smarty_Internal_Template $_smarty_tpl) {
?>
Hello <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
, Welcome to Smarty!<?php }
}
