<?php
/* Smarty version 3.1.33, created on 2020-01-08 08:50:15
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5e1589b7698b01_72972431',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '471dd67f1c2716d1ce6df2e6a620b79458c1b026' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\home.tpl',
      1 => 1578469811,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e1589b7698b01_72972431 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->_tplFunction->registerTplFunctions($_smarty_tpl, array (
  'showPost' => 
  array (
    'compiled_filepath' => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates_c\\471dd67f1c2716d1ce6df2e6a620b79458c1b026_0.file.home.tpl.php',
    'uid' => '471dd67f1c2716d1ce6df2e6a620b79458c1b026',
    'call_name' => 'smarty_template_function_showPost_6735025835e1589b7464599_87478073',
  ),
));
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



<h1>Create Post</h1>
<form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
" enctype="multipart/form-data"> 
    <label> Text </label>
    <input type="text" name="data"> <br />
    <label> Picture </label>
    <input type="file" name="media"> <br />
    <input type="hidden" name="token" value=<?php echo $_smarty_tpl->tpl_vars['postToken']->value;?>
>
    <input type="submit" value="Sent Post">
</form>
<?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'showPost', array('data'=>$_smarty_tpl->tpl_vars['allPosts']->value,'level'=>0), true);?>


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
/* smarty_template_function_showPost_6735025835e1589b7464599_87478073 */
if (!function_exists('smarty_template_function_showPost_6735025835e1589b7464599_87478073')) {
function smarty_template_function_showPost_6735025835e1589b7464599_87478073(Smarty_Internal_Template $_smarty_tpl,$params) {
$params = array_merge(array('data'=>0,'level'=>0), $params);
foreach ($params as $key => $value) {
$_smarty_tpl->tpl_vars[$key] = new Smarty_Variable($value, $_smarty_tpl->isRenderingCache);
}
?>

    <?php if (is_array($_smarty_tpl->tpl_vars['data']->value)) {?>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'postData');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['postData']->value) {
?>
        <?php if ($_smarty_tpl->tpl_vars['level']->value < 1) {?>
            <h2>Post</h2>
        <?php } else { ?>
            <h2>Comment</h2>
        <?php }?>
            <p>Creator: <?php echo $_smarty_tpl->tpl_vars['postData']->value['creator'];?>
</p>
            <p>Created: <?php echo $_smarty_tpl->tpl_vars['postData']->value['created'];?>
</p>
            <?php if (isset($_smarty_tpl->tpl_vars['postData']->value['text'])) {?>
                <p><?php echo $_smarty_tpl->tpl_vars['postData']->value['text'];?>
</p>
            <?php }?>
            <?php if (isset($_smarty_tpl->tpl_vars['postData']->value['imgUrl'])) {?>
                <img src="<?php echo $_smarty_tpl->tpl_vars['postData']->value['imgUrl'];?>
" width="100px" height="100px" alt="No Picture">
            <?php }?>
            <?php if ($_smarty_tpl->tpl_vars['level']->value < 1) {?>
            <h2>Create Comment</h2>
            <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
" enctype="multipart/form-data"> 
            <label> Text </label>
            <input type="text" name="data"> <br />
            <label> Picture </label>
            <input type="file" name="media"> <br />
            <input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['postData']->value['id'];?>
" name="parent">
            <input type="submit" value="Sent Comment">
            </form>
            <?php }?>
            <?php if (!empty($_smarty_tpl->tpl_vars['postData']->value['comment'])) {?>
            <?php $_smarty_tpl->smarty->ext->_tplFunction->callTemplateFunction($_smarty_tpl, 'showPost', array('data'=>$_smarty_tpl->tpl_vars['postData']->value['comment'],'level'=>$_smarty_tpl->tpl_vars['level']->value+1), true);?>

            <?php }?>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <?php }
}}
/*/ smarty_template_function_showPost_6735025835e1589b7464599_87478073 */
}
