<?php
/* Smarty version 3.1.33, created on 2020-01-08 08:39:55
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5e15874b741c96_55402715',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '384ee20c30dd20937295658c288c22b32180c4ca' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\login.tpl',
      1 => 1578469141,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5e15874b741c96_55402715 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
 
    <form method="POST" action="<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
"> 
        <label> E-Mail </label>
        <input type="text" name="email" required> <br />
        <label> Password </label>
        <input type="password" name="password" required> <br />
        <input type="hidden" name="token" value="<?php echo $_smarty_tpl->tpl_vars['token']->value;?>
" >
        <input type="submit"> 
        <?php if (isset($_smarty_tpl->tpl_vars['headerErrorMsg']->value)) {?>
            <p><?php echo $_smarty_tpl->tpl_vars['headerErrorMsg']->value;?>
</p>
        <?php }?>
    </form>

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
