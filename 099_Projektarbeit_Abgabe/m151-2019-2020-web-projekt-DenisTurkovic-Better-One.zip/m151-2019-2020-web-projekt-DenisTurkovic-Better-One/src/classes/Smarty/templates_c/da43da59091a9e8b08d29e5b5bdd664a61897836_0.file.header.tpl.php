<?php
/* Smarty version 3.1.33, created on 2020-01-05 20:15:15
  from 'C:\xampp\htdocs\m151-2019-2020-web-projekt-DenisTurkovic\src\classes\Smarty\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5e1235c33f29f5_33930362',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'da43da59091a9e8b08d29e5b5bdd664a61897836' => 
    array (
      0 => 'C:\\xampp\\htdocs\\m151-2019-2020-web-projekt-DenisTurkovic\\src\\classes\\Smarty\\templates\\header.tpl',
      1 => 1578251714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e1235c33f29f5_33930362 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
    <?php if (isset($_smarty_tpl->tpl_vars['headerTitle']->value)) {?>
        <title><?php echo $_smarty_tpl->tpl_vars['headerTitle']->value;?>
</title>
    <?php }?>
</head>

<body>
<header>
    <nav>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['navigation']->value, 'temp', false, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value => $_smarty_tpl->tpl_vars['temp']->value) {
?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['temp']->value["link"];?>
"><p><?php echo $_smarty_tpl->tpl_vars['temp']->value["name"];?>
</p></a>

        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </nav>
    <br>
</header><?php }
}
