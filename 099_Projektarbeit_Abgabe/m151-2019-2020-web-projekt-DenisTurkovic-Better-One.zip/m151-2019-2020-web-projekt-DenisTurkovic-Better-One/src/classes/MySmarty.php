<?php
namespace M151;
use Smarty;
class MySmarty
{
//-------------------------------------------------------------------------------------------------
    public $smarty = NULL;
    protected static $INSTANCE = NULL;
//-------------------------------------------------------------------------------------------------
    private function __construct() 
    {
        $this->smarty = new Smarty();
        // Configs
        $this->smarty->setTemplateDir('../src/classes/Smarty/templates/');
        $this->smarty->setCompileDir('../src/classes/Smarty/templates_c/');
        $this->smarty->setConfigDir('../src/classes/Smarty/configs/');
        $this->smarty->setCacheDir('../src/classes/Smarty/cache/');
        
    }
//-------------------------------------------------------------------------------------------------
    public static function getInstance() 
    {
        if (static::$INSTANCE == NULL) {
            static::$INSTANCE = new MySmarty();
        }
        return static::$INSTANCE;
    }
}

?>