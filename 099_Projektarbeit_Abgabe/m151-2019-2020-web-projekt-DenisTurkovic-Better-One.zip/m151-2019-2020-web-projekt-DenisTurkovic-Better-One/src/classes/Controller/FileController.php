<?php

namespace M151\Controller;
use M151\Request;
use M151\Model\UserModel;
use M151\FileSystem;

class FileController extends BaseController {
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
    }
//-------------------------------------------------------------------------------------------------
    public function getUserFile(Request $request) 
    {
        // TODO Check if User Valid && Berechtigung
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $id = $this->validateInput($request->getParam("id"));
        
        if (is_null($id)) {
            die("Error");
        }

        $filesys = new FileSystem(FileSystem::User);
        $file = $filesys->getFile($id);
        if (is_null($file)) {
            die("File not Found");
        }
        header("Content-Tpye: {$file['mimetype']}");
        header("Content-Disposition: inline");        
       # header("Content-Disposition: form-data; filename=\"{$file['name']}\"");
        readfile($file["path"]);
    }
//-------------------------------------------------------------------------------------------------
    public function getPostFile(Request $request) 
    {
        // TODO Check if User Valid && Berechtigung
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $id = $this->validateInput($request->getParam("id"));
        
        if (is_null($id)) {
            die("Error");
        }

        $filesys = new FileSystem(FileSystem::Post);
        $file = $filesys->getFile($id);
        if (is_null($file)) {
            die("File not Found");
        }

        header("Content-Tpye: {$file['mimetype']}");
        header("Content-Disposition: inline");        
        readfile($file["path"]);
    }
//-------------------------------------------------------------------------------------------------
    public function downloadUserFile(Request $request)
    {
        // TODO Check if User Valid && Berechtigung
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $id = $this->validateInput($request->getParam("id"));
        
        if (is_null($id)) {
            die("Error");
        }

        $filesys = new FileSystem(FileSystem::User);
        $file = $filesys->getFile($id);
        if (is_null($file)) {
            die("File not Found");
        }
        header("Content-Tpye: {$file['mimetype']}");
        header("Content-Disposition: form-data; filename=\"{$file['name']}\"");
        readfile($file["path"]);
    }
//-------------------------------------------------------------------------------------------------
    public function downloadPostFile(Request $request)
    {
        // TODO Check if User Valid && Berechtigung
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }
        
        $id = $this->validateInput($request->getParam("id"));
        
        if (is_null($id)) {
            die("Error");
        }

        $filesys = new FileSystem(FileSystem::Post);
        $file = $filesys->getFile($id);
        if (is_null($file)) {
            die("File not Found");
        }
        header("Content-Tpye: {$file['mimetype']}");
        header("Content-Disposition: attachment; filename=\"{$file['name']}\"");
        readfile($file["path"]);
    }
}

?>