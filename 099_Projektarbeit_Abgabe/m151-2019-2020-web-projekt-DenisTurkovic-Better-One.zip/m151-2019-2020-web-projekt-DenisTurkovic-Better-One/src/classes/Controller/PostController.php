<?php

namespace M151\Controller;
use M151\App;
use M151\Request;
use M151\FileSystem;
use M151\Model\PostModel;

class PostController extends BaseController {
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
    }
//-------------------------------------------------------------------------------------------------
    public function postBy($id, $limit)
    {
        $model = new PostModel();
        return $model->getPosts($id,$limit);
    }
//-------------------------------------------------------------------------------------------------
    public function postPost(Request $request)
    {
        $userid = $_SESSION["userid"];

        if (is_null($userid)) {
            // TODO ERROR
            echo "Unkown USer";
            return;
        }

        if (is_null($request->getParam("parent")))
            $this->createNewPost($request);
        else
            $this->appendPost($request);

        header("Location: /webroot/home");
    }
//-------------------------------------------------------------------------------------------------
    private function createNewPost(Request $request) 
    {
        $tokenname = "M151\\PC\\csrf";
        $data = $this->validateInput($request->getParam("data"));
        $token = $this->validateInput($request->getParam("token"));

        $file = $request->getParam("media");
        // TODO how to token?
        $model = new PostModel();
        $fileupload = !(is_null($file));

        if (!$fileupload && is_null($data) && $token != $_SESSION[$tokenname]) {
            // TODO ERROR
            echo "Error";
            return;
        }

        $modeldata = array(
            "creator" => $_SESSION["userid"],
            "data" => $data
        );
        
        $postid = $model->insertPost($modeldata);

        if ($fileupload && ($postid > 0)) {
            $filesys = new FileSystem(FileSystem::Post);
            $filesys->saveFile($file, $postid);
        }

    }
//-------------------------------------------------------------------------------------------------
    private function appendPost(Request $request)
    {
        $data = $this->validateInput($request->getParam("data"));
        $file = $request->getParam("media");
        $parent = $this->validateInput($request->getParam("parent"));       
        // TODO how to token?
        $model = new PostModel();
        $fileupload = !(is_null($file));
        if (!$fileupload && is_null($data) && is_null($parent)) {
            // TODO ERROR
            return;
        }

        $modeldata = array(
            "creator" => $_SESSION["userid"],
            "data" => $data,
            "parent" => $parent
        );
        
        $postid = $model->appendPost($modeldata);

        if ($fileupload && ($postid > 0)) {
            $filesys = new FileSystem(FileSystem::Post);
            $filesys->saveFile($file, $postid);
        }

    }
}

?>