<?php

namespace M151\Controller;
use M151\Database\DB;

class BaseController {
//-------------------------------------------------------------------------------------------------
    protected $dbConn = NULL;
    protected $BaseModel = NULL;
//-------------------------------------------------------------------------------------------------
    public function __construct()
    {
        $this->dbConn = DB::getInstance()->getConn();
    }
//-------------------------------------------------------------------------------------------------
    protected function validateInput($data) 
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return (isset($data) && 
                !empty($data) && 
                !is_null($data)) ? 
            $data : null;
    }
//-------------------------------------------------------------------------------------------------
    public function token()
    {
        return bin2hex(random_bytes(64));
    }
}

?>