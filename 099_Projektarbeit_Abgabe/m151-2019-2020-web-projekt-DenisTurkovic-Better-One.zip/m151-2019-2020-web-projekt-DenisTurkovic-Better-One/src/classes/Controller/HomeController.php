<?php

namespace M151\Controller;
use M151\App;
use M151\Request;
use M151\FileSystem;
use M151\View\HomeView;
use M151\Controller\PostController;


class HomeController extends BaseController {
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
    }
//-------------------------------------------------------------------------------------------------
    public function home()
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $tokenname = "M151\\PC\\csrf";
        $postController = new PostController();
        $data = $postController->postBy($_SESSION["userid"], 100);
        $view = new HomeView();
        $_SESSION[$tokenname] = $this->token();
        $view->injectData("allPosts", $data);
        $view->display(array("url" => "/webroot/post", "postToken" => $_SESSION[$tokenname]));
    }
//-------------------------------------------------------------------------------------------------
}

?>