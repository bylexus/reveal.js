<?php

namespace M151\Controller;
use M151\App;
use M151\Request;
use M151\FileSystem;
use M151\Model\FriendModel;
use M151\View\FriendView;


class FriendController extends BaseController {
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
    }
//-------------------------------------------------------------------------------------------------
    public function getFriends() 
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }
            
        $model = new FriendModel();
        $data = $model->getAllUsers(array("userid" => $_SESSION["userid"]));

        $view = new FriendView();
        $view->injectData("friendRequests", $data["friendRequests"]);
        unset($data["friendRequests"]);
        $view->injectData("users", $data);
        $view->display(NULL);
    }
//-------------------------------------------------------------------------------------------------
    public function sendFriendRequest(Request $request)
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $friendid = $this->validateInput($request->getParam("id"));

        if (is_null($friendid)) {
            // TODO Error
            echo "No ID Sent";
            return;
        }
        $model = new FriendModel();
        $data = array(
            "userid" => $_SESSION["userid"],
            "friendid" => $friendid
        );
        
        if ($model->sendFriendRequest($data))
            $this->getFriends();
        else {
            echo "Failed";
            return;
        }
    }
//-------------------------------------------------------------------------------------------------
    public function acceptFriendRequest(Request $request)
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $friendid = $this->validateInput($request->getParam("id"));

        if (is_null($friendid)) {
            // TODO Error
            echo "No ID Sent";
            return;
        }
        $model = new FriendModel();
        $data = array(
            "userid" => $_SESSION["userid"],
            "friendid" => $friendid
        );
        
        if ($model->acceptFriendRequest($data))
            $this->getFriends();
        else {
            echo "Failed";
            return;
        }

    }
//-------------------------------------------------------------------------------------------------
    public function denyFriendRequest(Request $request)
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $friendid = $this->validateInput($request->getParam("id"));

        if (is_null($friendid)) {
            // TODO Error
            echo "No ID Sent";
            return;
        }
        $model = new FriendModel();
        $data = array(
            "userid" => $_SESSION["userid"],
            "friendid" => $friendid
        );
        
        if ($model->denyFriendRequest($data))
            $this->getFriends();
        else {
            echo "Failed";
            return;
        }
    }
}

?>