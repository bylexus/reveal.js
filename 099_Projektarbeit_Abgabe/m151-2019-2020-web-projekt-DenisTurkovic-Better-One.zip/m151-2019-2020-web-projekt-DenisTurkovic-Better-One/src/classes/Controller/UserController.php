<?php

namespace M151\Controller;
use M151\App;
use M151\Request;
use M151\FileSystem;
use M151\Model\UserModel;
use M151\View\LoginView;
use M151\View\RegisterView;
use M151\View\EditView;

class UserController extends BaseController {
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
    public function __construct() 
    {
        parent::__construct();
    }
//-------------------------------------------------------------------------------------------------
    public function getLogin(Request $request)
    {
        $tokenName = "M151\\login\\csrf";
        $_SESSION[$tokenName] = $this->token();
        $view = new LoginView();
        $view->display(array("token" => $_SESSION[$tokenName]));
    }
//-------------------------------------------------------------------------------------------------
    public function postLogin(Request $request)
    {
        $tokenName = "M151\\login\\csrf";
        $email    = $this->validateInput($request->getParam("email"));
        $password = $this->validateInput($request->getParam("password"));
        $token    = $this->validateInput($request->getParam("token"));

        // TODO HASH password
        if (is_null($email) || is_null($password)) {
            // TODO Error
            return;
        }

        if (is_null($token) || $_SESSION[$tokenName] != $token) {
            // TODO Error

            return;
        }
        $data = array(
            "email" => $email,
            "password" => $password
        );

        $model = new UserModel();
        $userid = $model->getUser($data)["id"];
        if ($userid > 0) {
            $_SESSION["userid"] = $userid;
        } else {
            // TODO ERROR
            $this->getLogin($request);

        }
        // TODO Redirect to Home
        header('Location: /webroot/home');
    }
//-------------------------------------------------------------------------------------------------
    public function getRegister(Request $request)
    {
        $tokenName = "M151\\register\\csrf";
        $_SESSION[$tokenName] = $this->token();
        $view = new RegisterView();
        $view->display(array("token" => $_SESSION[$tokenName]));
    }
//-------------------------------------------------------------------------------------------------
    public function postRegister(Request $request)
    {
        $tokenName = "M151\\register\\csrf";

        // Bessere Lösung ?
        $email = $this->validateInput($request->getParam("email"));
        $password = $this->validateInput($request->getParam("password"));
        $secondpassword = $this->validateInput($request->getParam("secondpassword"));
        $firstname = $this->validateInput($request->getParam("firstname"));
        $surname = $this->validateInput($request->getParam("surname"));
        $token = $this->validateInput($request->getParam("token"));
        // TODO Files will be saved locally, name
        $picture = $request->getParam("picture");

        if (is_null($email)          || is_null($password)  ||
            is_null($secondpassword) || is_null($firstname) ||
            is_null($surname)        || is_null($picture)
        ) {
            // TODO Error
            $this->getRegister($request);
            return;
        }

        if (!($password == $secondpassword)) {
            // TODO Error
            return;
        }

        if (is_null($token) || $_SESSION[$tokenName] != $token) {
            // TODO Error
            return;
        }

        $password = password_hash($password, PASSWORD_DEFAULT);
        // TODO CHECK IF EMAIL EXISTS
        $data = array(
            "email" => $email,
            "password" => $password,
            "firstname" => $firstname,
            "surname" => $surname,
        );

        $model = new UserModel();
        $userid = $model->registerUser($data);
        
        $filesys = new FileSystem(FileSystem::User);
        $filesys->saveFile($picture, $userid);
        $_SESSION["userid"] = $userid;
        header('Location: /webroot/home');
        return;
    }
//-------------------------------------------------------------------------------------------------
    public function getEdit(Request $request)
    {
        if (empty($_SESSION["userid"])) {
            header('Location: /webroot/login');
            return;
        }

        $tokenName = "M151\\edit\\csrf";
        $_SESSION[$tokenName] = $this->token();
        $view = new EditView();
        $model = new UserModel();
        $user = $model->getUser(array("id" => $_SESSION["userid"]));
        $url = App::getInstance()->routeUrl("/file/user?id=");
        $displayData = array(
            "token" => $_SESSION[$tokenName], 
            "imgUrl" => $url . $_SESSION["userid"],
            "firstname" => $user["firstname"],
            "surname" => $user["surname"]
        );
        if (!(is_null($_SESSION["user\\error"]))) {
            $displayData["errorMsg"] = $_SESSION["user\\error"];
            unset($_SESSION["user\\error"]);
        }

        $view->display($displayData);
    }
//-------------------------------------------------------------------------------------------------
    public function postEdit(Request $request)
    {
        $tokenName = "M151\\edit\\csrf";

        $password = $this->validateInput($request->getParam("password"));
        $secondpassword = $this->validateInput($request->getParam("secondpassword"));
        $firstname = $this->validateInput($request->getParam("firstname"));
        $surname = $this->validateInput($request->getParam("surname"));
        $token = $this->validateInput($request->getParam("token"));
        $picture = $request->getParam("picture");

        if (is_null($password)  ||  is_null($secondpassword) 
        || is_null($firstname)  ||  is_null($surname)
        ) {
            $_SESSION["user\\error"] = "Missing Arguments, Please Check";
            $this->getEdit($request);
            return;
        }

        if (!($password == $secondpassword)) {
            $_SESSION["user\\error"] = "Passwords not equal";
            $this->getEdit($request);
            return;
        }

        if (is_null($token) && $_SESSION[$tokenName] != $token) {
            $_SESSION["user\\error"] = "Unkown Token, try again";
            $this->getEdit($request);
            return;
        }
        $model = new UserModel();
        $data = array(
            "firstname" => $firstname,
            "surname" => $surname,
            "userid" => $_SESSION["userid"],
            "password" => $password
        );

        if ($model->updateUser($data)) {
            if (!(is_null($picture))) {
                $filesys = new FileSystem(FileSystem::User);
                $filesys->putFile($picture, $_SESSION["userid"]);
            }
            $this->getEdit($request);
            return;
        } else {
            $_SESSION["user\\error"] = "Wrong Password, please check";
            $this->getEdit($request);
            return;
        }
    }
//-------------------------------------------------------------------------------------------------
    public function logout(Request $request)
    {
        //TODO implement
        session_destroy();
        header('Location: /webroot/login');
    }
}

?>