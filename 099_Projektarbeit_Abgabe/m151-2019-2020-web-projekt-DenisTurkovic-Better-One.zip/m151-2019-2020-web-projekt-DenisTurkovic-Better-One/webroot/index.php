<?php
session_start();

use M151\Router;
use M151\App;

# lade composer autoloader:
require_once __DIR__ . '/../vendor/autoload.php';

// get Router
$router = Router::getInstance();

// NotFaceBook Routes
$router->addRoute('/login', 'GET', 'M151\Controller\UserController', 'getLogin');
$router->addRoute('/login', 'POST', 'M151\Controller\UserController', 'postLogin');

$router->addRoute('/logout', 'GET', 'M151\Controller\UserController', 'logout');

$router->addRoute('/register', 'GET', 'M151\Controller\UserController', 'getRegister');
$router->addRoute('/register', 'POST', 'M151\Controller\UserController', 'postRegister');

$router->addRoute('/edit', 'GET', 'M151\Controller\UserController', 'getEdit');
$router->addRoute('/edit', 'POST', 'M151\Controller\UserController', 'postEdit');

$router->addRoute('/file/user', 'GET', 'M151\Controller\FileController', 'getUserFile');
$router->addRoute('/file/post', 'GET', 'M151\Controller\FileController', 'getPostFile');

$router->addRoute('/file/download/user', 'GET', 'M151\Controller\FileController', 'downloadUserFile');
$router->addRoute('/file/download/post', 'GET', 'M151\Controller\FileController', 'downloadPostFile');

$router->addRoute('/post', 'POST', 'M151\Controller\PostController', 'postPost');

$router->addRoute('/friend', 'GET', 'M151\Controller\FriendController', 'getFriends');
$router->addRoute('/friend/sent', 'POST', 'M151\Controller\FriendController', 'sendFriendRequest');
$router->addRoute('/friend/accept', 'POST', 'M151\Controller\FriendController', 'acceptFriendRequest');
$router->addRoute('/friend/deny', 'POST', 'M151\Controller\FriendController', 'denyFriendRequest');

$router->addRoute('/home' , 'GET', 'M151\Controller\HomeController', 'home');

// Start App
if(!(App::getInstance()->exec())) {
    header('Location: /webroot/login');
    return;
}

?>