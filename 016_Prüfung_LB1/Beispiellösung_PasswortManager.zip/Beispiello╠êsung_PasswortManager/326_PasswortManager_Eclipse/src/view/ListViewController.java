package view;

import java.util.List;

import logic.ProgramManager;
import model.PasswortEintrag;

public class ListViewController extends ViewController {
	
	public ListViewController(ListView view) {
		super(view);
	}
	
	public List<PasswortEintrag> getPWList() {
		return ProgramManager.getInstance().passwoerter;
	}
	
	
	@Override
	public void afterViewShow() {
		ListView view = (ListView)getView();
		
		if (view.selection.equals("")) {
			ProgramManager.getInstance().shutdown();
		}
		int index = Integer.parseInt(view.selection);
		if (index < getPWList().size() && index > -1) {
			ProgramManager.getInstance().addNext(new EditView(getPWList().get(index)));
		}
	}
}
