package view;

import java.rmi.AccessException;

import logic.ProgramManager;
import model.Benutzer;

public class LoginViewController extends ViewController {
	
	public LoginViewController(LoginView view) {
		super(view);
	}
	
	public void credentialsEntered(String username, String pw) {
		Benutzer b = null;
		
		if (pw.equals("")) {
			ProgramManager.getInstance().shutdown();
		}
		
		try {
			b = new Benutzer();
			b.setLogin(username);
			b.setPasswort(pw);
			ProgramManager.getInstance().load(b);
			((LoginView)view).loggedInUser = ProgramManager.getInstance().getBenutzer();
			
		} catch (AccessException e) {
			System.err.println(e.getMessage());
		}
	}
	
	@Override
	public void beforeViewShow() {
		ProgramManager.getInstance().setBenutzer(null);
	};
	
	@Override
	public void afterViewShow() {
		ProgramManager.getInstance().addNext(new ListView());
	}
}
