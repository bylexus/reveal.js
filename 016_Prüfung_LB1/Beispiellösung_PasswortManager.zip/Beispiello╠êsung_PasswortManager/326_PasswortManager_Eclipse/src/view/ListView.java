package view;

import java.util.List;

import logic.ProgramManager;
import model.PasswortEintrag;

public class ListView extends ConsoleView {
	protected String selection = "-1";
	
	public ListView() {
		this.setController(new ListViewController(this));
	}
	

	@Override
	public void displayView() {
		ListViewController ctrl = (ListViewController)controller;
		
		clearScreen();
		out("Passwort-Liste für "+ProgramManager.getInstance().getBenutzer().getLogin());
		out("=================================================");
		
		List<PasswortEintrag> list = ctrl.getPWList();
		
		for (int i = 0; i < list.size(); i++) {
			out(i + ": " + list.get(i).getTitel());
		}

		selection = ask("edit (nr)? ");
	}
}
