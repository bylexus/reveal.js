package view;

import model.Benutzer;

public class LoginView extends ConsoleView {
	String choose = "";
	Benutzer loggedInUser = null;
	
	public LoginView() {
		this.setController(new LoginViewController(this));
	}
	
	public String getChoose() {
		return choose;
	}
	

	@Override
	public void displayView() {
		String login,pass;
		clearScreen();
		this.loggedInUser = null;
		
		while (this.loggedInUser == null) {
			login = ask("Login:");
			pass = ask("Passwort:");
			((LoginViewController)controller).credentialsEntered(login, pass);
			
			if (this.loggedInUser == null) {
				out("*** Falsches Passwort. Nochmals. ***");
			}
		}
	}
}
