package view;

import model.PasswortEintrag;

public class EditViewController extends ViewController {
	protected PasswortEintrag eintrag;
	
	public EditViewController(EditView view, PasswortEintrag eintrag) {
		super(view);
		this.eintrag = eintrag;
	}
}
