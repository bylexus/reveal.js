package view;

import model.PasswortEintrag;

public class EditView extends ConsoleView {
	
	public EditView(PasswortEintrag eintrag) {
		this.setController(new EditViewController(this,eintrag));
	}
	

	@Override
	public void displayView() {
		EditViewController ctrl = (EditViewController)controller;
		
		clearScreen();
		
		out("Eintrag: " + ctrl.eintrag.getTitel());
		out("===============================================\n");
		out("Titel: "+ctrl.eintrag.getTitel());
		out("Beschreibung: "+ctrl.eintrag.getBeschreibung());
		out("Login: "+ctrl.eintrag.getLogin());
		out("Passwort: "+ctrl.eintrag.getPasswort());
		
		ask("\n\n? ");
	}
}
