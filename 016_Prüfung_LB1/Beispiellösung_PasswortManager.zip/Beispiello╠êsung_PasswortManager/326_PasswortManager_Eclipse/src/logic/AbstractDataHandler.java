package logic;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.JSONException;

import model.Benutzer;
import model.PasswortEintrag;

public abstract class AbstractDataHandler {
	public static AbstractDataHandler getDataHandler() {
		// für jetzt: es gibt nur einen json handler:
		return new JsonDataHandler();
	}
	
	public abstract void load(Benutzer b) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, JSONException ;
	public abstract void save(ProgramManager p);
	public abstract List<PasswortEintrag> getPasswords();
	
}
