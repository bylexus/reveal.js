package logic;

import java.rmi.AccessException;
import java.util.List;
import java.util.Stack;

import model.Benutzer;
import model.Kategorie;
import model.PasswortEintrag;
import model.Tag;
import view.View;

public class ProgramManager {
	private static ProgramManager _inst;
	
	
	Stack<View> viewStack;
	View currentView = null;
	
	public Benutzer benutzer = null;
	public List<Kategorie> kategorien;
	public List<Tag> tags;
	public List<PasswortEintrag> passwoerter;
	
	
	private ProgramManager() {
		viewStack = new Stack<>();
	}
	
	public static ProgramManager getInstance() {
			if (ProgramManager._inst == null) {
				ProgramManager._inst = new ProgramManager();
			}
			return ProgramManager._inst;
	}
	
	public void addNext(View view) {
		viewStack.push(view);
	}
	
	public View getCurrentView() {
		return this.currentView;
	}
	
	public void startCurrentView() {
		while (!viewStack.isEmpty()) {
			currentView = viewStack.peek();
			currentView.show();
			if (currentView != viewStack.peek()) {
				startCurrentView();
			} else {
				popCurrentView();
			}
		}
		shutdown();
	}
	
	public View popCurrentView() {
		View v = viewStack.pop(); 
		v.dispose();
		return v;
	}

	public Benutzer getBenutzer() {
		return benutzer;
	}

	public void setBenutzer(Benutzer benutzer) {
		this.benutzer = benutzer;
	}
	
	public void shutdown() {
		System.exit(0);
	}
	
	public void load(Benutzer b) throws AccessException {
		AbstractDataHandler handler = AbstractDataHandler.getDataHandler();
		try {
			handler.load(b);
			this.setBenutzer(b);
			this.passwoerter = handler.getPasswords();
		} catch (Exception e) {
			throw new AccessException("login failed");
		}
	}
}
