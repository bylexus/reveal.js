package logic;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONException;
import org.json.JSONObject;

import model.Benutzer;
import model.Kategorie;
import model.PasswortEintrag;
import model.Tag;

public class JsonDataHandler extends AbstractDataHandler {
	List<Kategorie> kategorien = new ArrayList<>();
	List<Tag> tags = new ArrayList<>();
	List<PasswortEintrag> passwoerter = new ArrayList<>();

	@Override
	public void load(Benutzer b) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, JSONException {
		// Schlüssel erzeugen:
		SecretKeySpec key = createKey(b.getPasswort());
			
		// verschlüsseltes File lesen, String entschlüsseln:
		String geheim = readFile("benutzer1-abc123.json.enc");
		//System.out.println("Gelesenes File: "+geheim);
		String text = decrypt(geheim, key);
		//System.out.println("Entschlüsselter Text: "+text);
		
		// JSON-Objekt aus String lesen (libary org.json muss geladen sein):
		JSONObject json = new JSONObject(text);
		//JSONArray entries = json.getJSONArray("entries");
		//System.out.println("Entries: " + entries.toString());
		
		this.kategorien.clear();
		this.tags.clear();
		this.passwoerter.clear();
		for (Object entry : json.getJSONArray("entries")) {
			JSONObject o = (JSONObject)entry;
			PasswortEintrag eintrag = new PasswortEintrag();
			eintrag.setTitel(o.getString("title"));
			eintrag.setLogin(o.getString("login"));
			eintrag.setPasswort(o.getString("password"));
			this.passwoerter.add(eintrag);
		}
	}

	@Override
	public void save(ProgramManager p) {
		// TODO Auto-generated method stub
	}
	
	public List<PasswortEintrag> getPasswords() {
		return this.passwoerter;
	}
	
	/**
	 * Schlüssel aus Plain-Text-Passwort erzeugen
	 * 
	 * @param plainPW das Passwort im Plain Text
	 * @return die Key-Instanz
	 * @throws NoSuchAlgorithmException
	 */
	public SecretKeySpec createKey(String plainPW) throws NoSuchAlgorithmException {
		// Das Passwort bzw der Schluesseltext
		String keyStr = plainPW;
		// byte-Array erzeugen
		byte[] key = (keyStr).getBytes();
		// aus dem Array einen Hash-Wert erzeugen mit MD5 oder SHA
		MessageDigest sha = MessageDigest.getInstance("SHA-256");
		key = sha.digest(key);
		// nur die ersten 128 bit nutzen
		key = Arrays.copyOf(key, 16); 
		// der fertige Schluessel
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
		return secretKeySpec;
	}
	
	/**
	 * Entschlüsselt ein verschlüsselter String
	 * 
	 * @param geheim Das Geheimnis, als base64-encoded AES-128-String
	 * @param key Die Key-Instanz
	 * @return Der entschlüsselte Text
	 * 
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public String decrypt(String geheim, SecretKeySpec key) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		// BASE64 String zu Byte-Array konvertieren
		byte[] crypted2 = Base64.getDecoder().decode(geheim);
		 
		// Entschluesseln
		Cipher cipher2 = Cipher.getInstance("AES");
		cipher2.init(Cipher.DECRYPT_MODE, key);
		byte[] cipherData2 = cipher2.doFinal(crypted2);
		String erg = new String(cipherData2);
		return erg;
	}
	
	/**
	 * Verschlüsselt einen String in einen base64-encoded AES-128-String 
	 * @param text Der Plain-Text
 	 * @param key Die Key-Instanz
	 * @return Der verschlüsselte String als base64-encoded AES-128-String
	 * 
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public String encrypt(String text, SecretKeySpec key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		// Verschluesseln
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] encrypted = cipher.doFinal(text.getBytes());
		 
		// bytes zu Base64-String konvertieren (dient der Lesbarkeit)
		String geheim = Base64.getEncoder().encodeToString(encrypted);
		return geheim;
	}
	
	/**
	 * Liest ein ganzes File in einen String
	 * @param path
	 * @return
	 */
	public String readFile(String path) {
		try {
			return new String(Files.readAllBytes(Paths.get(path)));
		} catch (IOException e) {
			return "";
		}
	}
	
	/**
	 * Schreibt einen String als Ganzes in ein File
	 * @param path
	 * @param content
	 * @return
	 */
	public boolean writeFile(String path, String content) {
		try {
			Files.write(Paths.get(path), content.getBytes());
			return true;
		} catch (IOException e) {
			return false;
		}
	}

}
