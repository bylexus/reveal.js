package model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class PasswortEintrag extends Model {
	private String titel;
	private Date datum;
	private Date ablaufdatum;
	private String beschreibung;
	private String login;
	private String passwort;
	private String url;
	private List<Tag> tagList = new ArrayList<>();
	private List<Kategorie> kategorieList = new ArrayList<>();
	
	public String getTitel() {
		return titel;
	}


	public void setTitel(String titel) {
		this.titel = titel;
	}


	public Date getDatum() {
		return datum;
	}


	public void setDatum(Date datum) {
		this.datum = datum;
	}


	public Date getAblaufdatum() {
		return ablaufdatum;
	}


	public void setAblaufdatum(Date ablaufdatum) {
		this.ablaufdatum = ablaufdatum;
	}


	public String getBeschreibung() {
		return beschreibung;
	}


	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}


	public String getLogin() {
		return login;
	}


	public void setLogin(String login) {
		this.login = login;
	}


	public String getPasswort() {
		return passwort;
	}


	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public List<Tag> getTagList() {
		return tagList;
	}


	public void setTagList(List<Tag> tagList) {
		this.tagList = tagList;
	}


	public List<Kategorie> getKategorieList() {
		return kategorieList;
	}


	public void setKategorieList(List<Kategorie> kategorieList) {
		this.kategorieList = kategorieList;
	}


	@Override
	public JSONObject toJsonObject() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return this.getTitel() + ", Passwort: "+this.getPasswort();
	}

}
