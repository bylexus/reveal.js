package model;

import org.json.JSONObject;

public abstract class Model implements IJsonModel {

	@Override
	public abstract JSONObject toJsonObject();
}
