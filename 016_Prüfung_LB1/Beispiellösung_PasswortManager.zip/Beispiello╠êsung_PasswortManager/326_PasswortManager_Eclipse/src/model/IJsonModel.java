package model;

import org.json.JSONObject;

public interface IJsonModel {
	public JSONObject toJsonObject();
}
