#!/bin/sh

java -cp "bin:jgoodies-common-1.6.0.jar:jgoodies-forms-1.8.0.jar" business.Main
