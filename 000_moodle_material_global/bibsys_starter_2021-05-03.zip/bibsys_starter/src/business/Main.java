package business;

public class Main {
	public static void main(String[] args) {
		// Start des Programms:
		ProgramManager pm = ProgramManager.getInstance();
		pm.startProgram();
	}
}
