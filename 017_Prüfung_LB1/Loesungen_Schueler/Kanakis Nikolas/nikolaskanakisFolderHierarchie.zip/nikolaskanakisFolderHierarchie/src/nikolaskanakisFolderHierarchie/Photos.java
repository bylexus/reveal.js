package nikolaskanakisFolderHierarchie;


public class Photos {
	
	public Photos()
	{
		
	}
	private Ordner parentOrdner;

}
