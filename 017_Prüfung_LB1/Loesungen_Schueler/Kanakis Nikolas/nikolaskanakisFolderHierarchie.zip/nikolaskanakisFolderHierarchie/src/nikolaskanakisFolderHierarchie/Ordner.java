package nikolaskanakisFolderHierarchie;

import java.util.List;

public class Ordner {
	
	public Ordner() 
	{
		
	}
	
	private List<Ordner> containingOrdner;
	private List<Photos> containingPhotos;
}
