
public interface IBild {
	public String getName();
}
