
public class Photo {
	public String Name;
	
	public Photo(String name)	
	{
		this.Name = name;

	}

}
