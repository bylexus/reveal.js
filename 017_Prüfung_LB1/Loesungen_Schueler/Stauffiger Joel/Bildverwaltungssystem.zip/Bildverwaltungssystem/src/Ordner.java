

public class Ordner {
	Ordner(String ordnername){
		setOrdner(ordnername);
	}
	public String getOrdner() {
		return ordner;
	}

	public void setOrdner(String ordner) {
		this.ordner = ordner;
	}
	String ordner;
	String unterordner;

}
