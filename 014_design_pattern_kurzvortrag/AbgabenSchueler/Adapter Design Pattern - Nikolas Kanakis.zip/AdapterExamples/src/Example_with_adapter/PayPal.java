package Example_with_adapter;

public class PayPal
{
	public void sendPayment(int amount)
	{
		System.out.println("Paying via PayPal:" + amount);
	}
}
