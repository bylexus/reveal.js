package Example_with_adapter;

public interface paymentAdapter 
{
	public void pay (int amount);
}
