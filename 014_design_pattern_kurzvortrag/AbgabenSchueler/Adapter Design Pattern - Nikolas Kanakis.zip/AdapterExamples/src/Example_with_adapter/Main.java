package Example_with_adapter;

public class Main {

	public static void main(String[] args) 
	{
		PayPalAdapter paypal = new PayPalAdapter(new PayPal());
		paypal.pay(1000);
		paypal.pay(2000);
		paypal.pay(3000);
		paypal.pay(4000);
		paypal.pay(5000);
		paypal.pay(6000);
	}

}

//In this example, we have not touched the PayPal class.

//What if PayPal is a class that changes a lot and 
//decides to rename the Method "sendPayment" to "payAmount"?
//Try and do this and see how many changes you have to make.

//You should realize, that you only have to change it once,
//In a bigger Program you would save a lot of time like this...