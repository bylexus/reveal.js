package Example_with_adapter;

public class PayPalAdapter implements paymentAdapter
{
	private PayPal paypal;
	
	public PayPalAdapter (PayPal paypal)
	{
		this.paypal = paypal;
	}
	
	public void pay(int amount) 
	{
		this.paypal.sendPayment(amount);
	}

}
