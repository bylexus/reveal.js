package Example_without_adapter;

public class PayPal
{
	public void sendPayment(int amount)
	{
		System.out.println("Paying via PayPal:" + amount);
	}
}