package Example_without_adapter;

public class Main {

	public static void main(String[] args)
	{
		PayPal paypal = new PayPal();
		
		paypal.sendPayment(1000);
		paypal.sendPayment(2000);
		paypal.sendPayment(3000);
		paypal.sendPayment(4000);
		paypal.sendPayment(5000);
		paypal.sendPayment(6000);
	}
}

//What if PayPal is a class that changes a lot and 
//decides to rename the Method "sendPayment" to "payAmount"?
//Try and do this and see how many changes you have to make.

//You should realize, that you have to change it as many times
//as the method is called. That could take some time in a bigger Program...